﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BTH2_Bai04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            // ===== PHẦN 1: Nhập 2 phân số và tính toán =====
            Console.WriteLine("=== NHẬP HAI PHÂN SỐ ===");
            Console.WriteLine("Nhập phân số thứ nhất");
            PhanSo a = new PhanSo();
            a.Nhap();

            Console.WriteLine("Nhập phân số thứ hai");
            PhanSo b = new PhanSo();
            b.Nhap();

            Console.WriteLine("\nHai phân số vừa nhập:");
            a.Xuat();
            Console.Write("\t");
            b.Xuat();

            Console.WriteLine($"\n\nTổng: {a + b}");
            Console.WriteLine($"Hiệu: {a - b}");
            Console.WriteLine($"Tích: {a * b}");
            PhanSo thuong = a / b;
            if (thuong != null)
                Console.WriteLine($"Thương: {thuong}");


            // ===== PHẦN 2: Làm việc với dãy phân số =====
            Console.WriteLine("\n=== NHẬP DÃY PHÂN SỐ ===");
            DayPhanSo d = new DayPhanSo();
            d.NhapDay();

            Console.WriteLine("\nDãy phân số ban đầu:");
            d.XuatDay();

            Console.WriteLine($"\nPhân số lớn nhất: {d.TimMax()}");

            d.SapXepTang();
            Console.WriteLine("\nDãy phân số sau khi sắp xếp tăng dần:");
            d.XuatDay();

            Console.WriteLine("\nHoàn thành!");
        }
    }

    // 🔹 Lớp PhanSo
    class PhanSo
    {
        protected int Tu;
        protected int Mau;

        public PhanSo()
        {
            Tu = 0;
            Mau = 1;
        }

        public PhanSo(int tu, int mau)
        {
            Tu = tu;
            Mau = mau;
        }

        // Rút gọn phân số
        public void RutGon()
        {
            int gcd = GCD(Math.Abs(Tu), Math.Abs(Mau));
            if (gcd == 0) return;
            Tu /= gcd;
            Mau /= gcd;
            if (Mau < 0)
            {
                Mau = -Mau;
                Tu = -Tu;
            }
        }

        private int GCD(int a, int b)
        {
            return b == 0 ? a : GCD(b, a % b);
        }

        // Tính giá trị thực
        public double GiaTri()
        {
            return (double)Tu / Mau;
        }

        // Nhập / Xuất
        public int NhapSoNguyen(string thongBao)
        {
            int so;
            bool hopLe;
            do
            {
                Console.Write(thongBao);
                string input = Console.ReadLine();
                hopLe = int.TryParse(input, out so);
                if (!hopLe)
                    Console.WriteLine("Vui lòng nhập SỐ NGUYÊN hợp lệ!");
            } while (!hopLe);
            return so;
        }

        public void Nhap()
        {
            Tu = NhapSoNguyen("Nhập tử số: ");

            do
            {
                Mau = NhapSoNguyen("Nhập mẫu số (≠ 0): ");
                if (Mau == 0)
                    Console.WriteLine("Mẫu số KHÔNG được bằng 0, vui lòng nhập lại!");
            } while (Mau == 0);
        }

        public void Xuat()
        {
            if (Mau == 1)
                Console.Write(Tu);
            else
                Console.Write($"{Tu}/{Mau}");
        }

        public override string ToString()
        {
            if (Mau == 1)
                return $"{Tu}";
            else
                return $"{Tu}/{Mau}";
        }

        // Toán tử + - * /
        public static PhanSo operator +(PhanSo a, PhanSo b)
        {
            PhanSo kq = new PhanSo(a.Tu * b.Mau + b.Tu * a.Mau, a.Mau * b.Mau);
            kq.RutGon();
            return kq;
        }

        public static PhanSo operator -(PhanSo a, PhanSo b)
        {
            PhanSo kq = new PhanSo(a.Tu * b.Mau - b.Tu * a.Mau, a.Mau * b.Mau);
            kq.RutGon();
            return kq;
        }

        public static PhanSo operator *(PhanSo a, PhanSo b)
        {
            PhanSo kq = new PhanSo(a.Tu * b.Tu, a.Mau * b.Mau);
            kq.RutGon();
            return kq;
        }

        public static PhanSo operator /(PhanSo a, PhanSo b)
        {
            if (b.Tu == 0)
            {
                Console.WriteLine("Không thể chia cho phân số có tử = 0!");
                return null;
            }

            PhanSo kq = new PhanSo(a.Tu * b.Mau, a.Mau * b.Tu);
            kq.RutGon();
            return kq;
        }


        // So sánh
        public static bool operator >(PhanSo a, PhanSo b)
        {
            return a.Tu * b.Mau > b.Tu * a.Mau;
        }

        public static bool operator <(PhanSo a, PhanSo b)
        {
            return a.Tu * b.Mau < b.Tu * a.Mau;
        }
    }

    // 🔹 Lớp DayPhanSo
    class DayPhanSo : PhanSo
    {
        private List<PhanSo> ds;

        public DayPhanSo()
        {
            ds = new List<PhanSo>();
        }

        public void NhapDay()
        {
            Console.Write("Nhập số lượng phân số: ");
            int n;
            while (!int.TryParse(Console.ReadLine(), out n) || n <= 0)
            {
                Console.Write("Nhập lại số lượng hợp lệ (>0): ");
            }

            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"\nPhân số thứ {i + 1}:");
                PhanSo p = new PhanSo();
                p.Nhap();
                ds.Add(p);
            }
        }

        public void XuatDay()
        {
            Console.WriteLine("Dãy phân số:");
            foreach (var p in ds)
                Console.Write(p + "  ");
            Console.WriteLine();
        }

        public PhanSo TimMax()
        {
            if (ds.Count == 0) return null;
            PhanSo max = ds[0];
            foreach (var p in ds)
                if (p > max)
                    max = p;
            return max;
        }

        public void SapXepTang()
        {
            ds.Sort(SoSanhPhanSoTang);
        }

        private int SoSanhPhanSoTang(PhanSo a, PhanSo b)
        {
            if (a < b)
                return -1;
            else if (a > b)
                return 1;
            else
                return 0;
        }

    }
}
