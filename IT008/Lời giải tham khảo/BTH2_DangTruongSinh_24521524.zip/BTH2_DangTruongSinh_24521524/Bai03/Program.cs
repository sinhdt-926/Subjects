﻿using System;
using System.Text;
namespace BTH2_Bai03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Matrix m = new Matrix();
            int[,] matrix = new int[0, 0];
            int row = 0, col = 0;
            int choice;

            do
            {
                m.Menu();
                Console.Write("Chọn chức năng: ");
                choice = NhapSoNguyen("");

                switch (choice)
                {
                    case 1:
                        Console.WriteLine("Nhập kích thước ma trận:");
                        row = NhapSoNguyen("Nhập số hàng: ");
                        col = NhapSoNguyen("Nhập số cột: ");
                        m.Input_Matrix(ref matrix, row, col);
                        break;

                    case 2:
                        if (matrix.Length == 0)
                            Console.WriteLine("Chưa có dữ liệu ma trận!");
                        else
                            m.Output_Matrix(matrix, row, col);
                        break;

                    case 3:
                        if (matrix.Length == 0)
                        {
                            Console.WriteLine("Chưa có dữ liệu ma trận!");
                            break;
                        }
                        int k = NhapSoNguyen("Nhập phần tử cần tìm: ");
                        bool found = m.Find_Element(matrix, row, col, k);
                        if (found)
                            Console.WriteLine("Phần tử tồn tại trong ma trận.");
                        else
                            Console.WriteLine("Không tìm thấy phần tử trong ma trận.");
                        break;

                    case 4:
                        if (matrix.Length == 0)
                            Console.WriteLine("Chưa có dữ liệu ma trận!");
                        else
                            m.Print_Prime_Elements(matrix, row, col);
                        break;

                    case 5:
                        if (matrix.Length == 0)
                            Console.WriteLine("Chưa có dữ liệu ma trận!");
                        else
                            m.Print_Row_With_Most_Primes(matrix, row, col);
                        break;

                    case 0:
                        Console.WriteLine("Kết thúc chương trình.");
                        break;

                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ. Vui lòng chọn lại!");
                        break;
                }

                Console.WriteLine();
            } while (choice != 0);
        }

        static int NhapSoNguyen(string thongBao)
        {
            int so;
            bool hopLe;
            do
            {
                if (thongBao != "")
                    Console.Write(thongBao);
                string input = Console.ReadLine();
                hopLe = int.TryParse(input, out so);
                if (!hopLe)
                    Console.WriteLine("Vui lòng nhập SỐ NGUYÊN hợp lệ!");
            } while (!hopLe);
            return so;
        }
    }

    class Matrix
    {
        public void Menu()
        {
            Console.WriteLine("====== MENU ======");
            Console.WriteLine("1. Nhập ma trận");
            Console.WriteLine("2. Xuất ma trận");
            Console.WriteLine("3. Tìm phần tử trong ma trận");
            Console.WriteLine("4. Xuất các phần tử là số nguyên tố");
            Console.WriteLine("5. Dòng có nhiều số nguyên tố nhất");
            Console.WriteLine("0. Thoát");
        }

        public void Input_Matrix(ref int[,] matrix, int row, int col)
        {
            matrix = new int[row, col];
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    Console.Write($"[{i}, {j}]: ");
                    matrix[i, j] = int.Parse(Console.ReadLine());
                }
            }
        }

        public void Output_Matrix(int[,] matrix, int row, int col)
        {
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    Console.Write($"{matrix[i, j],5}");
                }
                Console.WriteLine();
            }
        }

        public bool Find_Element(int[,] matrix, int row, int col, int k)
        {
            for (int i = 0; i < row; i++)
                for (int j = 0; j < col; j++)
                    if (matrix[i, j] == k)
                        return true;
            return false;
        }

        public bool Is_Prime(int x)
        {
            if (x < 2) return false;
            for (int i = 2; i <= Math.Sqrt(x); i++)
                if (x % i == 0) return false;
            return true;
        }

        public void Print_Prime_Elements(int[,] matrix, int row, int col)
        {
            List<int> primes = new List<int>();
            for (int i = 0; i < row; i++)
                for (int j = 0; j < col; j++)
                    if (Is_Prime(matrix[i, j]))
                        primes.Add(matrix[i, j]);

            if (primes.Count == 0)
                Console.WriteLine("Không có phần tử là số nguyên tố trong ma trận.");
            else
                Console.WriteLine(string.Join(" ", primes));
        }

        public void Print_Row_With_Most_Primes(int[,] matrix, int row, int col)
        {
            int[] primeCounts = new int[row];
            int maxCount = 0;

            // Đếm số nguyên tố trong từng dòng
            for (int i = 0; i < row; i++)
            {
                int count = 0;
                for (int j = 0; j < col; j++)
                    if (Is_Prime(matrix[i, j]))
                        count++;

                primeCounts[i] = count;
                if (count > maxCount)
                    maxCount = count;
            }

            if (maxCount == 0)
            {
                Console.WriteLine("Không có số nguyên tố nào trong ma trận.");
                return;
            }

            Console.Write("Dòng có nhiều số nguyên tố nhất: ");
            bool first = true;
            for (int i = 0; i < row; i++)
            {
                if (primeCounts[i] == maxCount)
                {
                    if (!first) Console.Write(", ");
                    Console.Write(i + 1);
                    first = false;
                }
            }
            Console.WriteLine();
        }

    }
}
