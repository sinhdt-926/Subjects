﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace DiaOcDaiPhu
{
    class Program
    {
        static void Main()
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;
            QuanLyDiaOc ql = new QuanLyDiaOc();

            ql.NhapDanhSach();
            ql.XuatDanhSach();
            ql.TongGiaBanTheoLoai();
            ql.LietKeTheoDieuKien();
            ql.TimKiem();

            Console.WriteLine("\n===> Chương trình kết thúc <===");
        }
    }

    // ======= LỚP CƠ SỞ =======
    class KhuDat
    {
        public string DiaDiem { get; set; }
        public long GiaBan { get; set; }
        public int DienTich { get; set; }

        public virtual void Nhap()
        {
            Console.Write("Nhập địa điểm: ");
            DiaDiem = Console.ReadLine();

            GiaBan = NhapSoNguyen("Nhập giá bán (VND): ", 0);
            DienTich = (int)NhapSoNguyen("Nhập diện tích (m2): ", 1);
        }

        public virtual void Xuat()
        {
            Console.WriteLine($"[Khu đất]  {DiaDiem,-15} | Giá: {GiaBan,12:N0} VND | Diện tích: {DienTich,6} m2");
        }

        protected long NhapSoNguyen(string thongBao, long min = long.MinValue)
        {
            long so;
            while (true)
            {
                Console.Write(thongBao);
                string input = Console.ReadLine();

                if (long.TryParse(input, out so))
                {
                    if (so >= min)
                        return so;
                    else
                        Console.WriteLine($"Giá trị phải >= {min}");
                }
                else
                {
                    Console.WriteLine("Lỗi: Vui lòng nhập SỐ NGUYÊN hợp lệ (không nhập chữ hoặc số thập phân)!");
                }
            }
        }
    }

    // ======= LỚP NHÀ PHỐ =======
    class NhaPho : KhuDat
    {
        public int NamXayDung { get; set; }
        public int SoTang { get; set; }

        public override void Nhap()
        {
            base.Nhap();
            NamXayDung = (int)NhapSoNguyen("Nhập năm xây dựng: ", 1);
            SoTang = (int)NhapSoNguyen("Nhập số tầng: ", 1);
        }

        public override void Xuat()
        {
            Console.WriteLine($"[Nhà phố]  {DiaDiem,-15} | Giá: {GiaBan,12:N0} VND | DT: {DienTich,6} m2 | Năm: {NamXayDung} | Tầng: {SoTang}");
        }
    }

    // ======= LỚP CHUNG CƯ =======
    class ChungCu : KhuDat
    {
        public int Tang { get; set; }

        public override void Nhap()
        {
            base.Nhap();
            Tang = (int)NhapSoNguyen("Nhập tầng: ", 0);
        }

        public override void Xuat()
        {
            Console.WriteLine($"[Chung cư] {DiaDiem,-15} | Giá: {GiaBan,12:N0} VND | DT: {DienTich,6} m2 | Tầng: {Tang}");
        }
    }

    // ======= LỚP QUẢN LÝ =======
    class QuanLyDiaOc
    {
        List<KhuDat> danhSach = new List<KhuDat>();

        public void NhapDanhSach()
        {
            while (true)
            {
                Console.WriteLine("\n--- Chọn loại bất động sản ---");
                Console.WriteLine("1. Khu đất");
                Console.WriteLine("2. Nhà phố");
                Console.WriteLine("3. Chung cư");
                Console.WriteLine("0. Thoát nhập");
                Console.Write("→ Chọn: ");
                string chon = Console.ReadLine();

                if (chon == "0") break;

                KhuDat item = null;
                switch (chon)
                {
                    case "1": item = new KhuDat(); break;
                    case "2": item = new NhaPho(); break;
                    case "3": item = new ChungCu(); break;
                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ!");
                        continue;
                }

                item.Nhap();
                danhSach.Add(item);
            }
        }

        public void XuatDanhSach()
        {
            Console.WriteLine("\n===== DANH SÁCH BẤT ĐỘNG SẢN =====");
            foreach (var item in danhSach)
                item.Xuat();
        }

        public void TongGiaBanTheoLoai()
        {
            long tongKhuDat = danhSach.OfType<KhuDat>().Where(x => x.GetType() == typeof(KhuDat)).Sum(x => x.GiaBan);
            long tongNhaPho = danhSach.OfType<NhaPho>().Sum(x => x.GiaBan);
            long tongChungCu = danhSach.OfType<ChungCu>().Sum(x => x.GiaBan);

            Console.WriteLine("\n===== TỔNG GIÁ BÁN THEO LOẠI =====");
            Console.WriteLine($"Khu đất  : {tongKhuDat:N0} VND");
            Console.WriteLine($"Nhà phố  : {tongNhaPho:N0} VND");
            Console.WriteLine($"Chung cư : {tongChungCu:N0} VND");
        }

        public void LietKeTheoDieuKien()
        {
            Console.WriteLine("\n===== KẾT QUẢ LỌC =====");
            var ketQua = danhSach.Where(x =>
                (x is KhuDat && x.GetType() == typeof(KhuDat) && x.DienTich > 100) ||
                (x is NhaPho np && np.DienTich > 60 && np.NamXayDung >= 2019)
            );

            if (!ketQua.Any())
            {
                Console.WriteLine("Không có kết quả nào phù hợp.");
                return;
            }

            foreach (var x in ketQua) x.Xuat();
        }

        public void TimKiem()
        {
            Console.Write("\nNhập địa điểm cần tìm: ");
            string diaDiem = Console.ReadLine().Trim().ToLower();
            long gia = NhapSoNguyen("Nhập giá tối đa (<=): ", 0);
            int dt = (int)NhapSoNguyen("Nhập diện tích tối thiểu (>=): ", 1);

            var ketQua = danhSach.Where(x =>
                (x is NhaPho || x is ChungCu) &&
                x.DiaDiem.ToLower().Contains(diaDiem) &&
                x.GiaBan <= gia &&
                x.DienTich >= dt
            ).ToList();

            Console.WriteLine("\n===== KẾT QUẢ TÌM KIẾM =====");
            if (!ketQua.Any())
                Console.WriteLine("Không có kết quả phù hợp.");
            else
                foreach (var x in ketQua) x.Xuat();
        }

        private long NhapSoNguyen(string thongBao, long min = long.MinValue)
        {
            long so;
            while (true)
            {
                Console.Write(thongBao);
                string input = Console.ReadLine();

                if (long.TryParse(input, out so))
                {
                    if (so >= min)
                        return so;
                    else
                        Console.WriteLine($"Giá trị phải >= {min}");
                }
                else
                {
                    Console.WriteLine("Lỗi: Vui lòng nhập SỐ NGUYÊN hợp lệ!");
                }
            }
        }
    }
}
