﻿using System;
using System.IO;
using System.Text;

namespace BTH2_Bai02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.InputEncoding = Encoding.UTF8;
            Console.Write("Nhập đường dẫn thư mục: ");
            string path = Console.ReadLine();

            DirectoryExplorer explorer = new DirectoryExplorer();
            explorer.ShowDirectory(path);
        }

    }

    class DirectoryExplorer
    {
        private int fileCount = 0;
        private int dirCount = 0;
        private long totalSize = 0;

        public void ShowDirectory(string path)
        {
            if (!Directory.Exists(path))
            {
                Console.WriteLine("Đường dẫn không tồn tại!");
                return;
            }

            // Lấy thông tin ổ đĩa
            string root = Path.GetPathRoot(path);
            DriveInfo drive = new DriveInfo(root);

            Console.WriteLine($"\n Volume in drive {drive.Name.Replace("\\", "")} is {drive.VolumeLabel}");
            Console.WriteLine($"\n Directory of {path}\n");

            // Liệt kê thư mục con
            string[] dirs = Directory.GetDirectories(path);
            foreach (string dir in dirs)
            {
                DirectoryInfo di = new DirectoryInfo(dir);
                Console.WriteLine($"{di.CreationTime:dd/MM/yyyy  hh:mm tt}\t<DIR>\t\t{di.Name}");
                dirCount++;
            }

            // Liệt kê tập tin
            string[] files = Directory.GetFiles(path);
            foreach (string file in files)
            {
                FileInfo fi = new FileInfo(file);
                Console.WriteLine($"{fi.CreationTime:dd/MM/yyyy  hh:mm tt}\t{fi.Length,10:N0}\t{fi.Name}");
                fileCount++;
                totalSize += fi.Length;
            }

            Console.WriteLine($"\n {fileCount} File(s)\t{totalSize,15:N0} bytes");
            Console.WriteLine($" {dirCount} Dir(s)\t{drive.AvailableFreeSpace,15:N0} bytes free");
        }
    }
}
