﻿using System;
using System.Text;

namespace BTH2_Bai01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.InputEncoding = Encoding.UTF8;
            Console.OutputEncoding = Encoding.UTF8;

            int month = NhapSoNguyen("Nhập tháng: ");
            int year = NhapSoNguyen("Nhập năm: ");

            Calendar calendar = new Calendar(month, year);

            if (calendar.IsValid())
                calendar.Print();
            else
                Console.WriteLine($"{month}/{year} không hợp lệ!");
        }

        static int NhapSoNguyen(string thongBao)
        {
            int so;
            bool hopLe;
            do
            {
                Console.Write(thongBao);
                string input = Console.ReadLine();
                hopLe = int.TryParse(input, out so);
                if (!hopLe)
                    Console.WriteLine("Vui lòng nhập SỐ NGUYÊN hợp lệ!");
            } while (!hopLe);
            return so;
        }
    }

    class Calendar
    {
        private int Month { get; set; }
        private int Year { get; set; }

        public Calendar(int month, int year)
        {
            Month = month;
            Year = year;
        }

        public bool IsValid()
        {
            return Month >= 1 && Month <= 12 && Year >= 1 && Year <= 9999;
        }

        private int GetFirstDayOfWeek()
        {
            DayOfWeek dayOfWeek = new DateTime(Year, Month, 1).DayOfWeek;
            return (int)dayOfWeek; 
        }

        private int GetDaysInMonth()
        {
            return DateTime.DaysInMonth(Year, Month);
        }

        public void Print()
        {
            Console.WriteLine($"\nTháng {Month}/{Year}\n");
            Console.WriteLine(" Sun Mon Tue Wed Thu Fri Sat");

            int startDay = GetFirstDayOfWeek();
            for (int i = 0; i < startDay; i++)
                Console.Write("    ");

            int days = GetDaysInMonth();
            int index = startDay;

            for (int i = 1; i <= days; i++)
            {
                Console.Write($"{i,4}");
                index++;
                if (index == 7)
                {
                    Console.WriteLine();
                    index = 0;
                }
            }

            Console.WriteLine("\n");
        }
    }
}
