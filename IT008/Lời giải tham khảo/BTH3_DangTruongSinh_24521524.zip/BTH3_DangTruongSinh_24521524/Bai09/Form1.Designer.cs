﻿namespace Bai09
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox_TTSV = new System.Windows.Forms.GroupBox();
            this.btn_XoaChon = new System.Windows.Forms.Button();
            this.btn_LuuThongTin = new System.Windows.Forms.Button();
            this.btn_RemoveCourse = new System.Windows.Forms.Button();
            this.btn_AddCourse = new System.Windows.Forms.Button();
            this.lb_CourseAdded = new System.Windows.Forms.ListBox();
            this.lb_Course = new System.Windows.Forms.ListBox();
            this.lbl_MonHoc = new System.Windows.Forms.Label();
            this.rBtn_Nu = new System.Windows.Forms.RadioButton();
            this.rBtn_Nam = new System.Windows.Forms.RadioButton();
            this.lbl_GioiTinh = new System.Windows.Forms.Label();
            this.cb_ChuyenNganh = new System.Windows.Forms.ComboBox();
            this.lbl_ChuyenNganh = new System.Windows.Forms.Label();
            this.lbl_Hoten = new System.Windows.Forms.Label();
            this.lbl_MSSV = new System.Windows.Forms.Label();
            this.txt_Hoten = new System.Windows.Forms.TextBox();
            this.txt_MSSV = new System.Windows.Forms.MaskedTextBox();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.dvg_ThongtinSinhvien = new System.Windows.Forms.DataGridView();
            this.MaSo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HoTen = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ChuyenNganh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GioiTinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoMon = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox_TTSV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvg_ThongtinSinhvien)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox_TTSV
            // 
            this.groupBox_TTSV.Controls.Add(this.btn_XoaChon);
            this.groupBox_TTSV.Controls.Add(this.btn_LuuThongTin);
            this.groupBox_TTSV.Controls.Add(this.btn_RemoveCourse);
            this.groupBox_TTSV.Controls.Add(this.btn_AddCourse);
            this.groupBox_TTSV.Controls.Add(this.lb_CourseAdded);
            this.groupBox_TTSV.Controls.Add(this.lb_Course);
            this.groupBox_TTSV.Controls.Add(this.lbl_MonHoc);
            this.groupBox_TTSV.Controls.Add(this.rBtn_Nu);
            this.groupBox_TTSV.Controls.Add(this.rBtn_Nam);
            this.groupBox_TTSV.Controls.Add(this.lbl_GioiTinh);
            this.groupBox_TTSV.Controls.Add(this.cb_ChuyenNganh);
            this.groupBox_TTSV.Controls.Add(this.lbl_ChuyenNganh);
            this.groupBox_TTSV.Controls.Add(this.lbl_Hoten);
            this.groupBox_TTSV.Controls.Add(this.lbl_MSSV);
            this.groupBox_TTSV.Controls.Add(this.txt_Hoten);
            this.groupBox_TTSV.Controls.Add(this.txt_MSSV);
            this.groupBox_TTSV.Location = new System.Drawing.Point(14, 5);
            this.groupBox_TTSV.Name = "groupBox_TTSV";
            this.groupBox_TTSV.Size = new System.Drawing.Size(914, 378);
            this.groupBox_TTSV.TabIndex = 0;
            this.groupBox_TTSV.TabStop = false;
            this.groupBox_TTSV.Text = "Thông tin sinh viên";
            // 
            // btn_XoaChon
            // 
            this.btn_XoaChon.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_XoaChon.Location = new System.Drawing.Point(399, 309);
            this.btn_XoaChon.Name = "btn_XoaChon";
            this.btn_XoaChon.Size = new System.Drawing.Size(112, 36);
            this.btn_XoaChon.TabIndex = 15;
            this.btn_XoaChon.Text = "Xoá chọn";
            this.btn_XoaChon.UseVisualStyleBackColor = true;
            // 
            // btn_LuuThongTin
            // 
            this.btn_LuuThongTin.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LuuThongTin.Location = new System.Drawing.Point(259, 309);
            this.btn_LuuThongTin.Name = "btn_LuuThongTin";
            this.btn_LuuThongTin.Size = new System.Drawing.Size(134, 36);
            this.btn_LuuThongTin.TabIndex = 14;
            this.btn_LuuThongTin.Text = "Lưu thông tin";
            this.btn_LuuThongTin.UseVisualStyleBackColor = true;
            // 
            // btn_RemoveCourse
            // 
            this.btn_RemoveCourse.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_RemoveCourse.Location = new System.Drawing.Point(377, 253);
            this.btn_RemoveCourse.Name = "btn_RemoveCourse";
            this.btn_RemoveCourse.Size = new System.Drawing.Size(50, 35);
            this.btn_RemoveCourse.TabIndex = 13;
            this.btn_RemoveCourse.Text = "<";
            this.btn_RemoveCourse.UseVisualStyleBackColor = true;
            // 
            // btn_AddCourse
            // 
            this.btn_AddCourse.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_AddCourse.Location = new System.Drawing.Point(377, 212);
            this.btn_AddCourse.Name = "btn_AddCourse";
            this.btn_AddCourse.Size = new System.Drawing.Size(50, 35);
            this.btn_AddCourse.TabIndex = 12;
            this.btn_AddCourse.Text = ">";
            this.btn_AddCourse.UseVisualStyleBackColor = true;
            // 
            // lb_CourseAdded
            // 
            this.lb_CourseAdded.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_CourseAdded.FormattingEnabled = true;
            this.lb_CourseAdded.ItemHeight = 17;
            this.lb_CourseAdded.Location = new System.Drawing.Point(445, 209);
            this.lb_CourseAdded.Name = "lb_CourseAdded";
            this.lb_CourseAdded.Size = new System.Drawing.Size(201, 89);
            this.lb_CourseAdded.TabIndex = 11;
            // 
            // lb_Course
            // 
            this.lb_Course.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Course.FormattingEnabled = true;
            this.lb_Course.ItemHeight = 17;
            this.lb_Course.Location = new System.Drawing.Point(157, 209);
            this.lb_Course.Name = "lb_Course";
            this.lb_Course.Size = new System.Drawing.Size(201, 89);
            this.lb_Course.TabIndex = 10;
            // 
            // lbl_MonHoc
            // 
            this.lbl_MonHoc.AutoSize = true;
            this.lbl_MonHoc.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MonHoc.Location = new System.Drawing.Point(162, 175);
            this.lbl_MonHoc.Name = "lbl_MonHoc";
            this.lbl_MonHoc.Size = new System.Drawing.Size(211, 20);
            this.lbl_MonHoc.TabIndex = 9;
            this.lbl_MonHoc.Text = "Chọn các môn học tham gia";
            // 
            // rBtn_Nu
            // 
            this.rBtn_Nu.AutoSize = true;
            this.rBtn_Nu.Location = new System.Drawing.Point(410, 137);
            this.rBtn_Nu.Name = "rBtn_Nu";
            this.rBtn_Nu.Size = new System.Drawing.Size(45, 20);
            this.rBtn_Nu.TabIndex = 8;
            this.rBtn_Nu.TabStop = true;
            this.rBtn_Nu.Text = "Nữ";
            this.rBtn_Nu.UseVisualStyleBackColor = true;
            // 
            // rBtn_Nam
            // 
            this.rBtn_Nam.AutoSize = true;
            this.rBtn_Nam.Location = new System.Drawing.Point(301, 136);
            this.rBtn_Nam.Name = "rBtn_Nam";
            this.rBtn_Nam.Size = new System.Drawing.Size(57, 20);
            this.rBtn_Nam.TabIndex = 7;
            this.rBtn_Nam.TabStop = true;
            this.rBtn_Nam.Text = "Nam";
            this.rBtn_Nam.UseVisualStyleBackColor = true;
            // 
            // lbl_GioiTinh
            // 
            this.lbl_GioiTinh.AutoSize = true;
            this.lbl_GioiTinh.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_GioiTinh.Location = new System.Drawing.Point(162, 136);
            this.lbl_GioiTinh.Name = "lbl_GioiTinh";
            this.lbl_GioiTinh.Size = new System.Drawing.Size(73, 20);
            this.lbl_GioiTinh.TabIndex = 6;
            this.lbl_GioiTinh.Text = "Giới tính";
            // 
            // cb_ChuyenNganh
            // 
            this.cb_ChuyenNganh.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_ChuyenNganh.FormattingEnabled = true;
            this.cb_ChuyenNganh.Location = new System.Drawing.Point(298, 89);
            this.cb_ChuyenNganh.Name = "cb_ChuyenNganh";
            this.cb_ChuyenNganh.Size = new System.Drawing.Size(213, 28);
            this.cb_ChuyenNganh.TabIndex = 5;
            // 
            // lbl_ChuyenNganh
            // 
            this.lbl_ChuyenNganh.AutoSize = true;
            this.lbl_ChuyenNganh.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ChuyenNganh.Location = new System.Drawing.Point(159, 97);
            this.lbl_ChuyenNganh.Name = "lbl_ChuyenNganh";
            this.lbl_ChuyenNganh.Size = new System.Drawing.Size(113, 20);
            this.lbl_ChuyenNganh.TabIndex = 4;
            this.lbl_ChuyenNganh.Text = "Chuyên ngành";
            // 
            // lbl_Hoten
            // 
            this.lbl_Hoten.AutoSize = true;
            this.lbl_Hoten.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Hoten.Location = new System.Drawing.Point(159, 61);
            this.lbl_Hoten.Name = "lbl_Hoten";
            this.lbl_Hoten.Size = new System.Drawing.Size(58, 20);
            this.lbl_Hoten.TabIndex = 3;
            this.lbl_Hoten.Text = "Họ tên";
            // 
            // lbl_MSSV
            // 
            this.lbl_MSSV.AutoSize = true;
            this.lbl_MSSV.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_MSSV.Location = new System.Drawing.Point(159, 27);
            this.lbl_MSSV.Name = "lbl_MSSV";
            this.lbl_MSSV.Size = new System.Drawing.Size(102, 20);
            this.lbl_MSSV.TabIndex = 2;
            this.lbl_MSSV.Text = "Mã sinh viên";
            // 
            // txt_Hoten
            // 
            this.txt_Hoten.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Hoten.Location = new System.Drawing.Point(298, 54);
            this.txt_Hoten.Name = "txt_Hoten";
            this.txt_Hoten.Size = new System.Drawing.Size(213, 28);
            this.txt_Hoten.TabIndex = 1;
            // 
            // txt_MSSV
            // 
            this.txt_MSSV.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MSSV.Location = new System.Drawing.Point(298, 19);
            this.txt_MSSV.Name = "txt_MSSV";
            this.txt_MSSV.Size = new System.Drawing.Size(115, 28);
            this.txt_MSSV.TabIndex = 0;
            // 
            // dvg_ThongtinSinhvien
            // 
            this.dvg_ThongtinSinhvien.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dvg_ThongtinSinhvien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MaSo,
            this.HoTen,
            this.ChuyenNganh,
            this.GioiTinh,
            this.SoMon});
            this.dvg_ThongtinSinhvien.Location = new System.Drawing.Point(14, 403);
            this.dvg_ThongtinSinhvien.Name = "dvg_ThongtinSinhvien";
            this.dvg_ThongtinSinhvien.RowHeadersWidth = 51;
            this.dvg_ThongtinSinhvien.RowTemplate.Height = 24;
            this.dvg_ThongtinSinhvien.Size = new System.Drawing.Size(914, 207);
            this.dvg_ThongtinSinhvien.TabIndex = 1;
            // 
            // MaSo
            // 
            this.MaSo.HeaderText = "MSSV";
            this.MaSo.MinimumWidth = 6;
            this.MaSo.Name = "MaSo";
            // 
            // HoTen
            // 
            this.HoTen.HeaderText = "Họ tên";
            this.HoTen.MinimumWidth = 6;
            this.HoTen.Name = "HoTen";
            this.HoTen.Width = 200;
            // 
            // ChuyenNganh
            // 
            this.ChuyenNganh.HeaderText = "Chuyên ngành";
            this.ChuyenNganh.MinimumWidth = 6;
            this.ChuyenNganh.Name = "ChuyenNganh";
            this.ChuyenNganh.Width = 200;
            // 
            // GioiTinh
            // 
            this.GioiTinh.HeaderText = "Giới tính";
            this.GioiTinh.MinimumWidth = 6;
            this.GioiTinh.Name = "GioiTinh";
            this.GioiTinh.Width = 90;
            // 
            // SoMon
            // 
            this.SoMon.HeaderText = "Số môn";
            this.SoMon.MinimumWidth = 6;
            this.SoMon.Name = "SoMon";
            this.SoMon.Width = 90;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(940, 678);
            this.Controls.Add(this.dvg_ThongtinSinhvien);
            this.Controls.Add(this.groupBox_TTSV);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.groupBox_TTSV.ResumeLayout(false);
            this.groupBox_TTSV.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dvg_ThongtinSinhvien)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox_TTSV;
        private System.Windows.Forms.Label lbl_MSSV;
        private System.Windows.Forms.TextBox txt_Hoten;
        private System.Windows.Forms.MaskedTextBox txt_MSSV;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private System.Windows.Forms.Label lbl_Hoten;
        private System.Windows.Forms.ComboBox cb_ChuyenNganh;
        private System.Windows.Forms.Label lbl_ChuyenNganh;
        private System.Windows.Forms.Button btn_XoaChon;
        private System.Windows.Forms.Button btn_LuuThongTin;
        private System.Windows.Forms.Button btn_RemoveCourse;
        private System.Windows.Forms.Button btn_AddCourse;
        private System.Windows.Forms.ListBox lb_CourseAdded;
        private System.Windows.Forms.ListBox lb_Course;
        private System.Windows.Forms.Label lbl_MonHoc;
        private System.Windows.Forms.RadioButton rBtn_Nu;
        private System.Windows.Forms.RadioButton rBtn_Nam;
        private System.Windows.Forms.Label lbl_GioiTinh;
        private System.Windows.Forms.DataGridView dvg_ThongtinSinhvien;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaSo;
        private System.Windows.Forms.DataGridViewTextBoxColumn HoTen;
        private System.Windows.Forms.DataGridViewTextBoxColumn ChuyenNganh;
        private System.Windows.Forms.DataGridViewTextBoxColumn GioiTinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoMon;
    }
}

