﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai09
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cb_ChuyenNganh.Items.AddRange(new object[] {
                "Công nghệ thông tin", "Khoa học dữ liệu", "Khoa học máy tính", "Trí tuệ nhân tạo", "Hệ thống thông tin", "Thương mại điện tử",
                "Mạng máy tính & truyền thông", "An toàn thông tin", "Kỹ thuật phần mềm", "Kỹ thuật máy tính" });
            lb_Course.Items.AddRange(new object[] {
                "Giải tích", "Đại số tuyến tính", "Cấu trúc rời rạc", "Xác suất thống kê", "Nhập môn lập trình", "Lập trình hướng đối tượng",
                "Cấu trúc dữ liệu và giải thuật", "Cơ sở dữ liệu", "Nhập môn mạng máy tính", "Hệ điều hành", "Lập trình trực quan" });

            btn_AddCourse.Click += Btn_AddCourse_Click;
            btn_RemoveCourse.Click += Btn_RemoveCourse_Click;
            btn_LuuThongTin.Click += Btn_LuuThongTin_Click;
            btn_XoaChon.Click += Btn_XoaChon_Click;
        }

        // Nút ">" - thêm môn học
        private void Btn_AddCourse_Click(object sender, EventArgs e)
        {
            if (lb_Course.SelectedItem != null)
            {
                object selected = lb_Course.SelectedItem;
                lb_CourseAdded.Items.Add(selected);
                lb_Course.Items.Remove(selected);
            }
        }

        // Nút "<" - trả môn học
        private void Btn_RemoveCourse_Click(object sender, EventArgs e)
        {
            if (lb_CourseAdded.SelectedItem != null)
            {
                object selected = lb_CourseAdded.SelectedItem;
                lb_Course.Items.Add(selected);
                lb_CourseAdded.Items.Remove(selected);
            }
        }

        // Nút "Lưu thông tin"
        private void Btn_LuuThongTin_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txt_MSSV.Text) || string.IsNullOrWhiteSpace(txt_Hoten.Text) || (!rBtn_Nu.Checked && !rBtn_Nam.Checked) || cb_ChuyenNganh.SelectedItem == null || lb_CourseAdded.Items.Count == 0)
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            string gioiTinh = rBtn_Nam.Checked ? "Nam" : "Nữ";
            int soMon = lb_CourseAdded.Items.Count;
            dvg_ThongtinSinhvien.Rows.Add(
                txt_MSSV.Text.Trim(),
                txt_Hoten.Text.Trim(),
                cb_ChuyenNganh.SelectedItem.ToString(),
                gioiTinh,
                soMon
            );

            txt_MSSV.Clear();
            txt_Hoten.Clear();
            cb_ChuyenNganh.SelectedIndex = -1;
            rBtn_Nam.Checked = false;
            rBtn_Nu.Checked = false;

            foreach (var item in lb_CourseAdded.Items)
            {
                lb_Course.Items.Add(item);
            }
            lb_CourseAdded.Items.Clear();
        }

        // Nút "Xoá chọn"
        private void Btn_XoaChon_Click(object sender, EventArgs e)
        {
            try
            {
                if (dvg_ThongtinSinhvien.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Vui lòng chọn sinh viên cần xoá!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                foreach (DataGridViewRow row in dvg_ThongtinSinhvien.SelectedRows)
                {
                    if (!row.IsNewRow)
                    {
                        dvg_ThongtinSinhvien.Rows.Remove(row);
                    }
                }
            }
            catch (Exception ex)
            {
                return ;
            }
        }
    }
}
