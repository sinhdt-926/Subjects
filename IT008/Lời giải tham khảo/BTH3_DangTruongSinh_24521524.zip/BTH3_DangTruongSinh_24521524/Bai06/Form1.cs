﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai06
{
    public partial class Form1 : Form
    {
        double value = 0;
        string operation = "";
        bool operation_pressed = false;
        double memory = 0;

        public Form1()
        {
            InitializeComponent();
            txt_Screen.Text = "0";
        }

        // Xử lý nút số và dấu chấm
        private void button_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;

            if (operation_pressed)
            {
                txt_Screen.Text = "";
                operation_pressed = false;
            }

            if (b.Text == ".")
            {
                if (!txt_Screen.Text.Contains("."))
                    txt_Screen.Text += ".";
            }
            else if (txt_Screen.Text == "0")
            {
                txt_Screen.Text = b.Text;
            }
            else
            {
                txt_Screen.Text += b.Text;
            }
        }

        // Xử lý nút phép toán
        private void operator_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;

            if (b.Text == "+/-")
            {
                if (double.TryParse(txt_Screen.Text, out double currentValue))
                    txt_Screen.Text = (-currentValue).ToString();
                return;
            }

            if (!double.TryParse(txt_Screen.Text, out double currentDisplayed))
            {
                txt_Screen.Text = "Error";
                return;
            }

            if (operation != "" && !operation_pressed)
            {
                btnBang.PerformClick();
            }

            value = double.Parse(txt_Screen.Text);
            operation = b.Text;
            operation_pressed = true;
        }

        // Xử lý nút "="
        private void btnBang_Click(object sender, EventArgs e)
        {
            if (operation == "") return;

            if (!double.TryParse(txt_Screen.Text, out double secondValue))
            {
                txt_Screen.Text = "Error";
                return;
            }

            double result = 0;

            try
            {
                switch (operation)
                {
                    case "+": result = value + secondValue; break;
                    case "-": result = value - secondValue; break;
                    case "*": result = value * secondValue; break;
                    case "/":
                        if (secondValue == 0)
                        {
                            txt_Screen.Text = "Cannot divide by zero";
                            operation = "";
                            operation_pressed = false;
                            return;
                        }
                        result = value / secondValue;
                        break;
                    default:
                        return;
                }

                txt_Screen.Text = result.ToString();
                value = result;
                operation = "";
                operation_pressed = true;
            }
            catch
            {
                txt_Screen.Text = "Error";
                operation = "";
                operation_pressed = false;
            }
        }

        // Xử lý nút C (Clear All)
        private void btn_C_Click(object sender, EventArgs e)
        {
            txt_Screen.Text = "0";
            value = 0;
            operation = "";
            operation_pressed = false;
        }

        // Xử lý nút CE (Clear Entry)
        private void btn_CE_Click(object sender, EventArgs e)
        {
            txt_Screen.Text = "0";
        }

        // Xử lý nút Backspace
        private void btn_Backspace_Click(object sender, EventArgs e)
        {
            if (txt_Screen.Text.Length > 0)
                txt_Screen.Text = txt_Screen.Text.Remove(txt_Screen.Text.Length - 1, 1);

            if (txt_Screen.Text == "")
                txt_Screen.Text = "0";
        }

        // Xử lý các phép toán sqrt, 1/x, %
        private void unary_operator_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;

            if (!double.TryParse(txt_Screen.Text, out double currentValue))
            {
                txt_Screen.Text = "Error";
                return;
            }

            try
            {
                switch (b.Text)
                {
                    case "sqrt":
                        txt_Screen.Text = currentValue >= 0 ? Math.Sqrt(currentValue).ToString() : "Invalid input";
                        break;

                    case "1/x":
                        txt_Screen.Text = currentValue != 0 ? (1 / currentValue).ToString() : "Cannot divide by zero";
                        break;

                    case "%":
                        txt_Screen.Text = (currentValue / 100).ToString();
                        break;
                }

                operation_pressed = false;
            }
            catch
            {
                txt_Screen.Text = "Error";
            }
        }

        // Xử lý bộ nhớ: MC, MR, MS, M+
        private void memory_button_Click(object sender, EventArgs e)
        {
            Button b = (Button)sender;
            double currentValue;

            if (b.Text != "MR" && !double.TryParse(txt_Screen.Text, out currentValue))
            {
                return;
            }

            try
            {
                switch (b.Text)
                {
                    case "MC":
                        memory = 0;
                        break;
                    case "MR":
                        txt_Screen.Text = memory.ToString();
                        operation_pressed = false;
                        break;
                    case "MS":
                        if (double.TryParse(txt_Screen.Text, out currentValue))
                            memory = currentValue;
                        break;
                    case "M+":
                        if (double.TryParse(txt_Screen.Text, out currentValue))
                            memory += currentValue;
                        break;
                }
            }
            catch
            {
                txt_Screen.Text = "Error";
            }
        }
    }
}