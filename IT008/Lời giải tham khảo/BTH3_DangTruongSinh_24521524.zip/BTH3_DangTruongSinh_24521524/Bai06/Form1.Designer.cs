﻿namespace Bai06
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnM_add = new System.Windows.Forms.Button();
            this.btn0 = new System.Windows.Forms.Button();
            this.btn_dot = new System.Windows.Forms.Button();
            this.btn_trans = new System.Windows.Forms.Button();
            this.btn3 = new System.Windows.Forms.Button();
            this.btn2 = new System.Windows.Forms.Button();
            this.btn1 = new System.Windows.Forms.Button();
            this.btn_MS = new System.Windows.Forms.Button();
            this.btn9 = new System.Windows.Forms.Button();
            this.btn8 = new System.Windows.Forms.Button();
            this.btn7 = new System.Windows.Forms.Button();
            this.btn_MC = new System.Windows.Forms.Button();
            this.btn6 = new System.Windows.Forms.Button();
            this.btn5 = new System.Windows.Forms.Button();
            this.bnt4 = new System.Windows.Forms.Button();
            this.btn_MR = new System.Windows.Forms.Button();
            this.btn_Sqrt = new System.Windows.Forms.Button();
            this.btnChia = new System.Windows.Forms.Button();
            this.btn_Percent = new System.Windows.Forms.Button();
            this.btnNhan = new System.Windows.Forms.Button();
            this.btnNghich = new System.Windows.Forms.Button();
            this.btnTru = new System.Windows.Forms.Button();
            this.btnBang = new System.Windows.Forms.Button();
            this.btnCong = new System.Windows.Forms.Button();
            this.btn_Backspace = new System.Windows.Forms.Button();
            this.btn_CE = new System.Windows.Forms.Button();
            this.btn_C = new System.Windows.Forms.Button();
            this.txt_Screen = new System.Windows.Forms.MaskedTextBox();
            this.SuspendLayout();
            // 
            // btnM_add
            // 
            this.btnM_add.AutoSize = true;
            this.btnM_add.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnM_add.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnM_add.Location = new System.Drawing.Point(24, 427);
            this.btnM_add.Name = "btnM_add";
            this.btnM_add.Size = new System.Drawing.Size(65, 55);
            this.btnM_add.TabIndex = 0;
            this.btnM_add.TabStop = false;
            this.btnM_add.Text = "M+";
            this.btnM_add.UseVisualStyleBackColor = true;
            this.btnM_add.Click += new System.EventHandler(this.memory_button_Click);
            // 
            // btn0
            // 
            this.btn0.AutoSize = true;
            this.btn0.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn0.Location = new System.Drawing.Point(106, 427);
            this.btn0.Name = "btn0";
            this.btn0.Size = new System.Drawing.Size(65, 55);
            this.btn0.TabIndex = 1;
            this.btn0.TabStop = false;
            this.btn0.Text = "0";
            this.btn0.UseVisualStyleBackColor = true;
            this.btn0.Click += new System.EventHandler(this.button_Click);
            // 
            // btn_dot
            // 
            this.btn_dot.AutoSize = true;
            this.btn_dot.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_dot.Location = new System.Drawing.Point(270, 425);
            this.btn_dot.Name = "btn_dot";
            this.btn_dot.Size = new System.Drawing.Size(65, 55);
            this.btn_dot.TabIndex = 3;
            this.btn_dot.TabStop = false;
            this.btn_dot.Text = ".";
            this.btn_dot.UseVisualStyleBackColor = true;
            this.btn_dot.Click += new System.EventHandler(this.button_Click);
            // 
            // btn_trans
            // 
            this.btn_trans.AutoSize = true;
            this.btn_trans.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_trans.Location = new System.Drawing.Point(188, 427);
            this.btn_trans.Name = "btn_trans";
            this.btn_trans.Size = new System.Drawing.Size(65, 55);
            this.btn_trans.TabIndex = 2;
            this.btn_trans.TabStop = false;
            this.btn_trans.Text = "+/-";
            this.btn_trans.UseVisualStyleBackColor = true;
            this.btn_trans.Click += new System.EventHandler(this.operator_Click);
            // 
            // btn3
            // 
            this.btn3.AutoSize = true;
            this.btn3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.Location = new System.Drawing.Point(270, 357);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(65, 55);
            this.btn3.TabIndex = 7;
            this.btn3.TabStop = false;
            this.btn3.Text = "3";
            this.btn3.UseVisualStyleBackColor = true;
            this.btn3.Click += new System.EventHandler(this.button_Click);
            // 
            // btn2
            // 
            this.btn2.AutoSize = true;
            this.btn2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.Location = new System.Drawing.Point(188, 359);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(65, 55);
            this.btn2.TabIndex = 6;
            this.btn2.TabStop = false;
            this.btn2.Text = "2";
            this.btn2.UseVisualStyleBackColor = true;
            this.btn2.Click += new System.EventHandler(this.button_Click);
            // 
            // btn1
            // 
            this.btn1.AutoSize = true;
            this.btn1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.Location = new System.Drawing.Point(106, 359);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(65, 55);
            this.btn1.TabIndex = 5;
            this.btn1.TabStop = false;
            this.btn1.Text = "1";
            this.btn1.UseVisualStyleBackColor = true;
            this.btn1.Click += new System.EventHandler(this.button_Click);
            // 
            // btn_MS
            // 
            this.btn_MS.AutoSize = true;
            this.btn_MS.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MS.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_MS.Location = new System.Drawing.Point(24, 359);
            this.btn_MS.Name = "btn_MS";
            this.btn_MS.Size = new System.Drawing.Size(65, 55);
            this.btn_MS.TabIndex = 4;
            this.btn_MS.TabStop = false;
            this.btn_MS.Text = "MS";
            this.btn_MS.UseVisualStyleBackColor = true;
            this.btn_MS.Click += new System.EventHandler(this.memory_button_Click);
            // 
            // btn9
            // 
            this.btn9.AutoSize = true;
            this.btn9.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.Location = new System.Drawing.Point(270, 221);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(65, 55);
            this.btn9.TabIndex = 15;
            this.btn9.TabStop = false;
            this.btn9.Text = "9";
            this.btn9.UseVisualStyleBackColor = true;
            this.btn9.Click += new System.EventHandler(this.button_Click);
            // 
            // btn8
            // 
            this.btn8.AutoSize = true;
            this.btn8.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.Location = new System.Drawing.Point(188, 221);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(65, 55);
            this.btn8.TabIndex = 14;
            this.btn8.TabStop = false;
            this.btn8.Text = "8";
            this.btn8.UseVisualStyleBackColor = true;
            this.btn8.Click += new System.EventHandler(this.button_Click);
            // 
            // btn7
            // 
            this.btn7.AutoSize = true;
            this.btn7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.Location = new System.Drawing.Point(106, 221);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(65, 55);
            this.btn7.TabIndex = 13;
            this.btn7.TabStop = false;
            this.btn7.Text = "7";
            this.btn7.UseVisualStyleBackColor = true;
            this.btn7.Click += new System.EventHandler(this.button_Click);
            // 
            // btn_MC
            // 
            this.btn_MC.AutoSize = true;
            this.btn_MC.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MC.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_MC.Location = new System.Drawing.Point(24, 221);
            this.btn_MC.Name = "btn_MC";
            this.btn_MC.Size = new System.Drawing.Size(65, 55);
            this.btn_MC.TabIndex = 12;
            this.btn_MC.TabStop = false;
            this.btn_MC.Text = "MC";
            this.btn_MC.UseVisualStyleBackColor = true;
            this.btn_MC.Click += new System.EventHandler(this.memory_button_Click);
            // 
            // btn6
            // 
            this.btn6.AutoSize = true;
            this.btn6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.Location = new System.Drawing.Point(270, 289);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(65, 55);
            this.btn6.TabIndex = 11;
            this.btn6.TabStop = false;
            this.btn6.Text = "6";
            this.btn6.UseVisualStyleBackColor = true;
            this.btn6.Click += new System.EventHandler(this.button_Click);
            // 
            // btn5
            // 
            this.btn5.AutoSize = true;
            this.btn5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.Location = new System.Drawing.Point(188, 289);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(65, 55);
            this.btn5.TabIndex = 10;
            this.btn5.TabStop = false;
            this.btn5.Text = "5";
            this.btn5.UseVisualStyleBackColor = true;
            this.btn5.Click += new System.EventHandler(this.button_Click);
            // 
            // bnt4
            // 
            this.bnt4.AutoSize = true;
            this.bnt4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bnt4.Location = new System.Drawing.Point(106, 289);
            this.bnt4.Name = "bnt4";
            this.bnt4.Size = new System.Drawing.Size(65, 55);
            this.bnt4.TabIndex = 9;
            this.bnt4.TabStop = false;
            this.bnt4.Text = "4";
            this.bnt4.UseVisualStyleBackColor = true;
            this.bnt4.Click += new System.EventHandler(this.button_Click);
            // 
            // btn_MR
            // 
            this.btn_MR.AutoSize = true;
            this.btn_MR.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MR.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_MR.Location = new System.Drawing.Point(24, 289);
            this.btn_MR.Name = "btn_MR";
            this.btn_MR.Size = new System.Drawing.Size(65, 55);
            this.btn_MR.TabIndex = 8;
            this.btn_MR.TabStop = false;
            this.btn_MR.Text = "MR";
            this.btn_MR.UseVisualStyleBackColor = true;
            this.btn_MR.Click += new System.EventHandler(this.memory_button_Click);
            // 
            // btn_Sqrt
            // 
            this.btn_Sqrt.AutoSize = true;
            this.btn_Sqrt.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Sqrt.Location = new System.Drawing.Point(434, 221);
            this.btn_Sqrt.Name = "btn_Sqrt";
            this.btn_Sqrt.Size = new System.Drawing.Size(65, 55);
            this.btn_Sqrt.TabIndex = 23;
            this.btn_Sqrt.TabStop = false;
            this.btn_Sqrt.Text = "sqrt";
            this.btn_Sqrt.UseVisualStyleBackColor = true;
            this.btn_Sqrt.Click += new System.EventHandler(this.unary_operator_Click);
            // 
            // btnChia
            // 
            this.btnChia.AutoSize = true;
            this.btnChia.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChia.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnChia.Location = new System.Drawing.Point(352, 221);
            this.btnChia.Name = "btnChia";
            this.btnChia.Size = new System.Drawing.Size(65, 55);
            this.btnChia.TabIndex = 22;
            this.btnChia.TabStop = false;
            this.btnChia.Text = "/";
            this.btnChia.UseVisualStyleBackColor = true;
            this.btnChia.Click += new System.EventHandler(this.operator_Click);
            // 
            // btn_Percent
            // 
            this.btn_Percent.AutoSize = true;
            this.btn_Percent.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Percent.Location = new System.Drawing.Point(434, 289);
            this.btn_Percent.Name = "btn_Percent";
            this.btn_Percent.Size = new System.Drawing.Size(65, 55);
            this.btn_Percent.TabIndex = 21;
            this.btn_Percent.TabStop = false;
            this.btn_Percent.Text = "%";
            this.btn_Percent.UseVisualStyleBackColor = true;
            this.btn_Percent.Click += new System.EventHandler(this.unary_operator_Click);
            // 
            // btnNhan
            // 
            this.btnNhan.AutoSize = true;
            this.btnNhan.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhan.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnNhan.Location = new System.Drawing.Point(352, 289);
            this.btnNhan.Name = "btnNhan";
            this.btnNhan.Size = new System.Drawing.Size(65, 55);
            this.btnNhan.TabIndex = 20;
            this.btnNhan.TabStop = false;
            this.btnNhan.Text = "*";
            this.btnNhan.UseVisualStyleBackColor = true;
            this.btnNhan.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnNghich
            // 
            this.btnNghich.AutoSize = true;
            this.btnNghich.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNghich.Location = new System.Drawing.Point(434, 357);
            this.btnNghich.Name = "btnNghich";
            this.btnNghich.Size = new System.Drawing.Size(65, 55);
            this.btnNghich.TabIndex = 19;
            this.btnNghich.TabStop = false;
            this.btnNghich.Text = "1/x";
            this.btnNghich.UseVisualStyleBackColor = true;
            this.btnNghich.Click += new System.EventHandler(this.unary_operator_Click);
            // 
            // btnTru
            // 
            this.btnTru.AutoSize = true;
            this.btnTru.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTru.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnTru.Location = new System.Drawing.Point(352, 357);
            this.btnTru.Name = "btnTru";
            this.btnTru.Size = new System.Drawing.Size(65, 55);
            this.btnTru.TabIndex = 18;
            this.btnTru.TabStop = false;
            this.btnTru.Text = "-";
            this.btnTru.UseVisualStyleBackColor = true;
            this.btnTru.Click += new System.EventHandler(this.operator_Click);
            // 
            // btnBang
            // 
            this.btnBang.AutoSize = true;
            this.btnBang.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnBang.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBang.ForeColor = System.Drawing.Color.White;
            this.btnBang.Location = new System.Drawing.Point(434, 425);
            this.btnBang.Name = "btnBang";
            this.btnBang.Size = new System.Drawing.Size(65, 55);
            this.btnBang.TabIndex = 17;
            this.btnBang.TabStop = false;
            this.btnBang.Text = "=";
            this.btnBang.UseVisualStyleBackColor = false;
            this.btnBang.Click += new System.EventHandler(this.btnBang_Click);
            // 
            // btnCong
            // 
            this.btnCong.AutoSize = true;
            this.btnCong.Font = new System.Drawing.Font("Times New Roman", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCong.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btnCong.Location = new System.Drawing.Point(352, 425);
            this.btnCong.Name = "btnCong";
            this.btnCong.Size = new System.Drawing.Size(65, 55);
            this.btnCong.TabIndex = 16;
            this.btnCong.TabStop = false;
            this.btnCong.Text = "+";
            this.btnCong.UseVisualStyleBackColor = true;
            this.btnCong.Click += new System.EventHandler(this.operator_Click);
            // 
            // btn_Backspace
            // 
            this.btn_Backspace.AutoSize = true;
            this.btn_Backspace.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Backspace.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_Backspace.Location = new System.Drawing.Point(106, 157);
            this.btn_Backspace.Name = "btn_Backspace";
            this.btn_Backspace.Size = new System.Drawing.Size(147, 40);
            this.btn_Backspace.TabIndex = 24;
            this.btn_Backspace.TabStop = false;
            this.btn_Backspace.Text = "Backspace";
            this.btn_Backspace.UseVisualStyleBackColor = true;
            this.btn_Backspace.Click += new System.EventHandler(this.btn_Backspace_Click);
            // 
            // btn_CE
            // 
            this.btn_CE.AutoSize = true;
            this.btn_CE.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_CE.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_CE.Location = new System.Drawing.Point(270, 157);
            this.btn_CE.Name = "btn_CE";
            this.btn_CE.Size = new System.Drawing.Size(129, 40);
            this.btn_CE.TabIndex = 25;
            this.btn_CE.TabStop = false;
            this.btn_CE.Text = "CE";
            this.btn_CE.UseVisualStyleBackColor = true;
            this.btn_CE.Click += new System.EventHandler(this.btn_CE_Click);
            // 
            // btn_C
            // 
            this.btn_C.AutoSize = true;
            this.btn_C.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_C.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.btn_C.Location = new System.Drawing.Point(405, 157);
            this.btn_C.Name = "btn_C";
            this.btn_C.Size = new System.Drawing.Size(94, 40);
            this.btn_C.TabIndex = 26;
            this.btn_C.TabStop = false;
            this.btn_C.Text = "C";
            this.btn_C.UseVisualStyleBackColor = true;
            this.btn_C.Click += new System.EventHandler(this.btn_C_Click);
            // 
            // txt_Screen
            // 
            this.txt_Screen.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Screen.Location = new System.Drawing.Point(27, 46);
            this.txt_Screen.Name = "txt_Screen";
            this.txt_Screen.Size = new System.Drawing.Size(475, 42);
            this.txt_Screen.TabIndex = 27;
            this.txt_Screen.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(527, 497);
            this.Controls.Add(this.txt_Screen);
            this.Controls.Add(this.btn_C);
            this.Controls.Add(this.btn_CE);
            this.Controls.Add(this.btn_Backspace);
            this.Controls.Add(this.btn_Sqrt);
            this.Controls.Add(this.btnChia);
            this.Controls.Add(this.btn_Percent);
            this.Controls.Add(this.btnNhan);
            this.Controls.Add(this.btnNghich);
            this.Controls.Add(this.btnTru);
            this.Controls.Add(this.btnBang);
            this.Controls.Add(this.btnCong);
            this.Controls.Add(this.btn9);
            this.Controls.Add(this.btn8);
            this.Controls.Add(this.btn7);
            this.Controls.Add(this.btn_MC);
            this.Controls.Add(this.btn6);
            this.Controls.Add(this.btn5);
            this.Controls.Add(this.bnt4);
            this.Controls.Add(this.btn_MR);
            this.Controls.Add(this.btn3);
            this.Controls.Add(this.btn2);
            this.Controls.Add(this.btn1);
            this.Controls.Add(this.btn_MS);
            this.Controls.Add(this.btn_dot);
            this.Controls.Add(this.btn_trans);
            this.Controls.Add(this.btn0);
            this.Controls.Add(this.btnM_add);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Caculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnM_add;
        private System.Windows.Forms.Button btn0;
        private System.Windows.Forms.Button btn_dot;
        private System.Windows.Forms.Button btn_trans;
        private System.Windows.Forms.Button btn3;
        private System.Windows.Forms.Button btn2;
        private System.Windows.Forms.Button btn1;
        private System.Windows.Forms.Button btn_MS;
        private System.Windows.Forms.Button btn9;
        private System.Windows.Forms.Button btn8;
        private System.Windows.Forms.Button btn7;
        private System.Windows.Forms.Button btn_MC;
        private System.Windows.Forms.Button btn6;
        private System.Windows.Forms.Button btn5;
        private System.Windows.Forms.Button bnt4;
        private System.Windows.Forms.Button btn_MR;
        private System.Windows.Forms.Button btn_Sqrt;
        private System.Windows.Forms.Button btnChia;
        private System.Windows.Forms.Button btn_Percent;
        private System.Windows.Forms.Button btnNhan;
        private System.Windows.Forms.Button btnNghich;
        private System.Windows.Forms.Button btnTru;
        private System.Windows.Forms.Button btnBang;
        private System.Windows.Forms.Button btnCong;
        private System.Windows.Forms.Button btn_Backspace;
        private System.Windows.Forms.Button btn_CE;
        private System.Windows.Forms.Button btn_C;
        private System.Windows.Forms.MaskedTextBox txt_Screen;
    }
}

