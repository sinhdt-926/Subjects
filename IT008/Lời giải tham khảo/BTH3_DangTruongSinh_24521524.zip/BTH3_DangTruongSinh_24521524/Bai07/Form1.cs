﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai07
{
    public partial class Form1 : Form
    {
        private Dictionary<Button, int> gheGia = new Dictionary<Button, int>();
        private bool chonLuotMoi = true;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            TaoGhe();
        }

        private void TaoGhe()
        {
            int gheSo = 1;

            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    Button btn = new Button();
                    btn.Text = gheSo.ToString();
                    btn.Dock = DockStyle.Fill;
                    btn.Margin = new Padding(5);
                    btn.BackColor = Color.White;
                    btn.Font = new Font("Segoe UI", 10, FontStyle.Bold);
                    btn.Click += Ghe_Click;

                    tableLayoutPanelGhe.Controls.Add(btn, j, i);

                    if (i == 0) gheGia[btn] = 5000;    
                    else if (i == 1) gheGia[btn] = 6500; 
                    else gheGia[btn] = 8000;             

                    gheSo++;
                }
            }
        }

        private void Ghe_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;

            if (chonLuotMoi)
            {
                txtThanhTien.Clear();
                chonLuotMoi = false;
            }    
            if (btn.BackColor == Color.White)
                btn.BackColor = Color.LightBlue; 
            else if (btn.BackColor == Color.LightBlue)
                btn.BackColor = Color.White; 
            else if (btn.BackColor == Color.Yellow)
                MessageBox.Show($"Ghế {btn.Text} đã bán!", "Thông báo",MessageBoxButtons.OK, MessageBoxIcon.Information);                
        }

        private void btnChon_Click(object sender, EventArgs e)
        {
            int tongTien = 0;

            foreach (var ghe in gheGia)
            {
                if (ghe.Key.BackColor == Color.LightBlue)
                {
                    ghe.Key.BackColor = Color.Yellow; 
                    tongTien += ghe.Value;
                }
            }

            txtThanhTien.Text = tongTien.ToString();
            chonLuotMoi = true;
        }

        private void btnHuy_Click(object sender, EventArgs e)
        {
            foreach (var ghe in gheGia)
            {
                if (ghe.Key.BackColor == Color.LightBlue)
                    ghe.Key.BackColor = Color.White;
            }

            txtThanhTien.Text = "0";
        }

        private void bntKet_Thuc_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("Bạn có muốn thoát chương trình không?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (r == DialogResult.Yes)
                this.Close();
        }

    }
}
