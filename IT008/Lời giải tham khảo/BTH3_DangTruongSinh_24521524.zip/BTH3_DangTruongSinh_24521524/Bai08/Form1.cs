﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai08
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listViewTaiKhoan.FullRowSelect = true;
            listViewTaiKhoan.GridLines = true;
            listViewTaiKhoan.View = View.Details;
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtSTK.Text) || string.IsNullOrWhiteSpace(txtTenKH.Text) || string.IsNullOrWhiteSpace(txtDiaChiKH.Text) || string.IsNullOrWhiteSpace(txtSoTienTK.Text))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thiếu dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ListViewItem itemTonTai = null;
            foreach (ListViewItem item in listViewTaiKhoan.Items)
            {
                if (item.SubItems[1].Text == txtSTK.Text)
                {
                    itemTonTai = item;
                    break;
                }
            }

            if (itemTonTai == null)
            {
                int stt = listViewTaiKhoan.Items.Count + 1;
                ListViewItem item = new ListViewItem(stt.ToString());
                item.SubItems.Add(txtSTK.Text);
                item.SubItems.Add(txtTenKH.Text);
                item.SubItems.Add(txtDiaChiKH.Text);
                item.SubItems.Add(txtSoTienTK.Text);
                listViewTaiKhoan.Items.Add(item);

                MessageBox.Show("Thêm mới dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                itemTonTai.SubItems[2].Text = txtTenKH.Text;
                itemTonTai.SubItems[3].Text = txtDiaChiKH.Text;
                itemTonTai.SubItems[4].Text = txtSoTienTK.Text;

                MessageBox.Show("Cập nhật dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            TinhTongTien();
            XoaTrang();
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            string soTK = txtSTK.Text.Trim();

            if (soTK == "")
            {
                MessageBox.Show("Vui lòng nhập số tài khoản cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ListViewItem itemCanXoa = null;
            foreach (ListViewItem item in listViewTaiKhoan.Items)
            {
                if (item.SubItems[1].Text == soTK)
                {
                    itemCanXoa = item;
                    break;
                }
            }

            if (itemCanXoa == null)
            {
                MessageBox.Show("Không tìm thấy số tài khoản cần xóa!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DialogResult r = MessageBox.Show("Bạn có chắc muốn xóa tài khoản này không?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (r == DialogResult.Yes)
            {
                listViewTaiKhoan.Items.Remove(itemCanXoa);
                MessageBox.Show("Xóa tài khoản thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                for (int i = 0; i < listViewTaiKhoan.Items.Count; i++)
                {
                    listViewTaiKhoan.Items[i].SubItems[0].Text = (i + 1).ToString();
                }

                TinhTongTien();
                XoaTrang();
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult r = MessageBox.Show("Bạn có muốn thoát chương trình không?", "Xác nhận thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                                            
            if (r == DialogResult.Yes)
                this.Close();
        }

        private void listViewTaiKhoan_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listViewTaiKhoan.SelectedItems.Count > 0)
            {
                ListViewItem item = listViewTaiKhoan.SelectedItems[0];
                txtSTK.Text = item.SubItems[1].Text;
                txtTenKH.Text = item.SubItems[2].Text;
                txtDiaChiKH.Text = item.SubItems[3].Text;
                txtSoTienTK.Text = item.SubItems[4].Text;
            }
        }

        private void XoaTrang()
        {
            txtSTK.Clear();
            txtTenKH.Clear();
            txtDiaChiKH.Clear();
            txtSoTienTK.Clear();
            txtSTK.Focus();
        }

        private void TinhTongTien()
        {
            double tong = 0;
            foreach (ListViewItem item in listViewTaiKhoan.Items)
            {
                if (double.TryParse(item.SubItems[4].Text, out double tien))
                    tong += tien;
            }
            txtTongTien.Text = tong.ToString();
        }
    }
}