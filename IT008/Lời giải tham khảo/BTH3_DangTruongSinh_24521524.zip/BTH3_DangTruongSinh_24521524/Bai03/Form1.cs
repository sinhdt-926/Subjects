﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnChangeColor_Click(object sender, EventArgs e)
        {
            this.BackColor = GetRandomColor();
        }

        private Color GetRandomColor()
        {
            Random random = new Random();
            int a = random.Next(0, 256);
            int b = random.Next(0, 256);
            int c = random.Next(0, 256);
            return Color.FromArgb(a, b, c);
        }
    }
}
