﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai05
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Kiểm tra dữ liệu nhập của người dùng
        private bool KiemTraSo(TextBox txt)
        {
            double value;
            if (!double.TryParse(txt.Text, out value))
            {
                MessageBox.Show("Vui lòng nhập đúng số!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                txt.Clear();
                txt.Focus();
                return false;
            }
            return true;
        }

        //Phép cộng
        private void btnCong_Click(object sender, EventArgs e)
        {
            if (!KiemTraSo(txtNum1) || !KiemTraSo(txtNum2))
                return;
            double num1 = double.Parse(txtNum1.Text);
            double num2 = double.Parse(txtNum2.Text);
            txtAnswer.Text = (num1 + num2).ToString();
        }

        //Phép trừ
        private void btnTru_Click(object sender, EventArgs e)
        {
            if (!KiemTraSo(txtNum1) || !KiemTraSo(txtNum2))
                return;
            double num1 = double.Parse(txtNum1.Text);
            double num2 = double.Parse(txtNum2.Text);
            txtAnswer.Text = (num1 - num2).ToString();
        }

        //Phép nhân
        private void btnNhan_Click(object sender, EventArgs e)
        {
            if (!KiemTraSo(txtNum1) || !KiemTraSo(txtNum2))
                return;
            double num1 = double.Parse(txtNum1.Text);
            double num2 = double.Parse(txtNum2.Text);
            txtAnswer.Text = (num1 * num2).ToString();
        }

        //Phép chia
        private void btnChia_Click(object sender, EventArgs e)
        {
            if (!KiemTraSo(txtNum1) || !KiemTraSo(txtNum2))
                return;
            double num1 = double.Parse(txtNum1.Text);
            double num2 = double.Parse(txtNum2.Text);
            if (num2 == 0)
            {
                MessageBox.Show("Không thể chia cho 0!", "Lỗi",
                                MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum2.Focus();
                return;
            }
            txtAnswer.Text = (num1 / num2).ToString();
        }
    }
}
