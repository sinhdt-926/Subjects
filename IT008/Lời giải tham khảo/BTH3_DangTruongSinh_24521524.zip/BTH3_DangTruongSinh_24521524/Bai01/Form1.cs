﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Bai01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listBox_FormEvent.Items.Add(DateTime.Now.ToString("dd:MM:yyyy - HH:mm:ss") + " - Form Load");
            listBox_FormEvent.TopIndex = listBox_FormEvent.Items.Count - 1;
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            listBox_FormEvent.Items.Add(DateTime.Now.ToString("dd:MM:yyyy - HH:mm:ss") + " - Form Click");
            listBox_FormEvent.TopIndex = listBox_FormEvent.Items.Count - 1;
        }

        private void Form1_Activated(object sender, EventArgs e)
        {
            listBox_FormEvent.Items.Add(DateTime.Now.ToString("dd:MM:yyyy - HH:mm:ss") + " - Form Activated");
            listBox_FormEvent.TopIndex = listBox_FormEvent.Items.Count - 1;
        }

        private void Form1_Deactivate(object sender, EventArgs e)
        {
            listBox_FormEvent.Items.Add(DateTime.Now.ToString("dd:MM:yyyy - HH:mm:ss") + " - Form Deactivate");
            listBox_FormEvent.TopIndex = listBox_FormEvent.Items.Count - 1;
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            listBox_FormEvent.Items.Add(DateTime.Now.ToString("dd:MM:yyyy - HH:mm:ss") + " - Form Resize");
            listBox_FormEvent.TopIndex = listBox_FormEvent.Items.Count - 1;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            listBox_FormEvent.Items.Add(DateTime.Now.ToString("dd:MM:yyyy - HH:mm:ss") + " - Form Closing");
            listBox_FormEvent.TopIndex = listBox_FormEvent.Items.Count - 1;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            listBox_FormEvent.Items.Add(DateTime.Now.ToString("dd:MM:yyyy - HH:mm:ss") + " - Form Closed");
            listBox_FormEvent.TopIndex = listBox_FormEvent.Items.Count - 1;

            MessageBox.Show("Form đã đóng");
        }
    }
}