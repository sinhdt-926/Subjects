﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            this.Text = "Paint Event";
            this.Click += new EventHandler(Form1_Click);
        }
        private void Form1_Click(object sender, EventArgs e)
        {
            this.Invalidate();
        }

        Random random = new Random();

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            SizeF textSize = e.Graphics.MeasureString("Paint Event", new Font("Arial", 20));
            int x = random.Next((int)(this.ClientSize.Width - textSize.Width));
            int y = random.Next((int)(this.ClientSize.Height - textSize.Height));
            e.Graphics.DrawString("Paint Event", new Font("Arial", 20, FontStyle.Bold), Brushes.Black, x, y);
        }
        private void Form1_Load(object sender, EventArgs e)
        {

            this.Paint += Form1_Paint;
        }
    }
}
