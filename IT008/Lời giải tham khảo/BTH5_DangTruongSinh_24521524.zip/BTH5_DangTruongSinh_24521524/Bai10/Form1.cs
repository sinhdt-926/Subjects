﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai10
{
    public partial class Form1 : Form
    {
        private List<Point> points = new List<Point>();

        private DashStyle dashStyle = DashStyle.DashDot;
        private float width = 5;
        private LineJoin lineJoin = LineJoin.Round;
        private LineCap startCap = LineCap.Triangle;
        private LineCap endCap = LineCap.RoundAnchor;
        private DashCap dashCap = DashCap.Triangle;

        private Bitmap canvas;

        public Form1()
        {
            InitializeComponent();

            canvas = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            pictureBox1.Image = canvas;

            LoadComboBoxes();

            cb_DashStyle.SelectedIndexChanged += UpdateSettings;
            cb_Width.SelectedIndexChanged += UpdateSettings;
            cb_LineJoin.SelectedIndexChanged += UpdateSettings;
            cb_StartCap.SelectedIndexChanged += UpdateSettings;
            cb_EndCap.SelectedIndexChanged += UpdateSettings;
            cb_DashCap.SelectedIndexChanged += UpdateSettings;

            pictureBox1.MouseClick += PictureBox1_MouseClick;
            pictureBox1.Paint += PictureBox1_Paint;
        }

        void LoadComboBoxes()
        {
            cb_DashStyle.Items.AddRange(Enum.GetNames(typeof(DashStyle)));
            cb_LineJoin.Items.AddRange(Enum.GetNames(typeof(LineJoin)));
            cb_StartCap.Items.AddRange(Enum.GetNames(typeof(LineCap)));
            cb_EndCap.Items.AddRange(Enum.GetNames(typeof(LineCap)));
            cb_DashCap.Items.AddRange(Enum.GetNames(typeof(DashCap)));

            for (int i = 1; i <= 15; i++) cb_Width.Items.Add(i.ToString());

            cb_DashStyle.Text = "DashDot";
            cb_Width.Text = "5";
            cb_LineJoin.Text = "Round";
            cb_StartCap.Text = "Triangle";
            cb_EndCap.Text = "RoundAnchor";
            cb_DashCap.Text = "Triangle";
        }

        void UpdateSettings(object s, EventArgs e)
        {
            dashStyle = (DashStyle)Enum.Parse(typeof(DashStyle), cb_DashStyle.Text);
            float.TryParse(cb_Width.Text, out width);
            lineJoin = (LineJoin)Enum.Parse(typeof(LineJoin), cb_LineJoin.Text);
            startCap = (LineCap)Enum.Parse(typeof(LineCap), cb_StartCap.Text);
            endCap = (LineCap)Enum.Parse(typeof(LineCap), cb_EndCap.Text);
            dashCap = (DashCap)Enum.Parse(typeof(DashCap), cb_DashCap.Text);
            pictureBox1.Invalidate();
        }

        void PictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                points.Add(e.Location);
                pictureBox1.Invalidate();
            }
            else if (e.Button == MouseButtons.Right)
            {
                if (points.Count >= 2)
                {
                    using (Graphics g = Graphics.FromImage(canvas))
                    using (Pen p = CreatePen())
                    {
                        g.SmoothingMode = SmoothingMode.AntiAlias;
                        g.DrawLines(p, points.ToArray());
                    }
                }

                points.Clear();
                pictureBox1.Invalidate();
            }
        }

        void PictureBox1_Paint(object sender, PaintEventArgs e)
        {
            if (points.Count < 2) return;

            using (Pen p = CreatePen())
            {
                e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
                e.Graphics.DrawLines(p, points.ToArray());
            }
        }

        Pen CreatePen()
        {
            Pen p = new Pen(Color.Red, width);
            p.DashStyle = dashStyle;
            p.LineJoin = lineJoin;
            p.StartCap = startCap;
            p.EndCap = endCap;
            p.DashCap = dashCap;
            return p;
        }
    }
}