﻿namespace Bai10
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pn_Tool = new System.Windows.Forms.Panel();
            this.cb_EndCap = new System.Windows.Forms.ComboBox();
            this.cb_StartCap = new System.Windows.Forms.ComboBox();
            this.cb_DashCap = new System.Windows.Forms.ComboBox();
            this.cb_LineJoin = new System.Windows.Forms.ComboBox();
            this.cb_Width = new System.Windows.Forms.ComboBox();
            this.cb_DashStyle = new System.Windows.Forms.ComboBox();
            this.lbl_EndCap = new System.Windows.Forms.Label();
            this.lbl_StartCap = new System.Windows.Forms.Label();
            this.lbl_DashCap = new System.Windows.Forms.Label();
            this.lbl_LineJoin = new System.Windows.Forms.Label();
            this.lbl_Width = new System.Windows.Forms.Label();
            this.lbl_DashStyle = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pn_Tool.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pn_Tool
            // 
            this.pn_Tool.BackColor = System.Drawing.SystemColors.Info;
            this.pn_Tool.Controls.Add(this.cb_EndCap);
            this.pn_Tool.Controls.Add(this.cb_StartCap);
            this.pn_Tool.Controls.Add(this.cb_DashCap);
            this.pn_Tool.Controls.Add(this.cb_LineJoin);
            this.pn_Tool.Controls.Add(this.cb_Width);
            this.pn_Tool.Controls.Add(this.cb_DashStyle);
            this.pn_Tool.Controls.Add(this.lbl_EndCap);
            this.pn_Tool.Controls.Add(this.lbl_StartCap);
            this.pn_Tool.Controls.Add(this.lbl_DashCap);
            this.pn_Tool.Controls.Add(this.lbl_LineJoin);
            this.pn_Tool.Controls.Add(this.lbl_Width);
            this.pn_Tool.Controls.Add(this.lbl_DashStyle);
            this.pn_Tool.Dock = System.Windows.Forms.DockStyle.Left;
            this.pn_Tool.Location = new System.Drawing.Point(0, 0);
            this.pn_Tool.Name = "pn_Tool";
            this.pn_Tool.Size = new System.Drawing.Size(256, 450);
            this.pn_Tool.TabIndex = 0;
            // 
            // cb_EndCap
            // 
            this.cb_EndCap.FormattingEnabled = true;
            this.cb_EndCap.Location = new System.Drawing.Point(120, 354);
            this.cb_EndCap.Name = "cb_EndCap";
            this.cb_EndCap.Size = new System.Drawing.Size(121, 24);
            this.cb_EndCap.TabIndex = 11;
            // 
            // cb_StartCap
            // 
            this.cb_StartCap.FormattingEnabled = true;
            this.cb_StartCap.Location = new System.Drawing.Point(120, 290);
            this.cb_StartCap.Name = "cb_StartCap";
            this.cb_StartCap.Size = new System.Drawing.Size(121, 24);
            this.cb_StartCap.TabIndex = 10;
            // 
            // cb_DashCap
            // 
            this.cb_DashCap.FormattingEnabled = true;
            this.cb_DashCap.Location = new System.Drawing.Point(120, 226);
            this.cb_DashCap.Name = "cb_DashCap";
            this.cb_DashCap.Size = new System.Drawing.Size(121, 24);
            this.cb_DashCap.TabIndex = 9;
            // 
            // cb_LineJoin
            // 
            this.cb_LineJoin.FormattingEnabled = true;
            this.cb_LineJoin.Location = new System.Drawing.Point(120, 162);
            this.cb_LineJoin.Name = "cb_LineJoin";
            this.cb_LineJoin.Size = new System.Drawing.Size(121, 24);
            this.cb_LineJoin.TabIndex = 8;
            // 
            // cb_Width
            // 
            this.cb_Width.FormattingEnabled = true;
            this.cb_Width.Location = new System.Drawing.Point(120, 98);
            this.cb_Width.Name = "cb_Width";
            this.cb_Width.Size = new System.Drawing.Size(121, 24);
            this.cb_Width.TabIndex = 7;
            // 
            // cb_DashStyle
            // 
            this.cb_DashStyle.FormattingEnabled = true;
            this.cb_DashStyle.Location = new System.Drawing.Point(120, 34);
            this.cb_DashStyle.Name = "cb_DashStyle";
            this.cb_DashStyle.Size = new System.Drawing.Size(121, 24);
            this.cb_DashStyle.TabIndex = 6;
            // 
            // lbl_EndCap
            // 
            this.lbl_EndCap.AutoSize = true;
            this.lbl_EndCap.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_EndCap.Location = new System.Drawing.Point(17, 357);
            this.lbl_EndCap.Name = "lbl_EndCap";
            this.lbl_EndCap.Size = new System.Drawing.Size(78, 20);
            this.lbl_EndCap.TabIndex = 5;
            this.lbl_EndCap.Text = "End Cap:";
            // 
            // lbl_StartCap
            // 
            this.lbl_StartCap.AutoSize = true;
            this.lbl_StartCap.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_StartCap.Location = new System.Drawing.Point(17, 293);
            this.lbl_StartCap.Name = "lbl_StartCap";
            this.lbl_StartCap.Size = new System.Drawing.Size(85, 20);
            this.lbl_StartCap.TabIndex = 4;
            this.lbl_StartCap.Text = "Start Cap:";
            // 
            // lbl_DashCap
            // 
            this.lbl_DashCap.AutoSize = true;
            this.lbl_DashCap.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DashCap.Location = new System.Drawing.Point(17, 229);
            this.lbl_DashCap.Name = "lbl_DashCap";
            this.lbl_DashCap.Size = new System.Drawing.Size(89, 20);
            this.lbl_DashCap.TabIndex = 3;
            this.lbl_DashCap.Text = "Dash Cap:";
            // 
            // lbl_LineJoin
            // 
            this.lbl_LineJoin.AutoSize = true;
            this.lbl_LineJoin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_LineJoin.Location = new System.Drawing.Point(17, 165);
            this.lbl_LineJoin.Name = "lbl_LineJoin";
            this.lbl_LineJoin.Size = new System.Drawing.Size(82, 20);
            this.lbl_LineJoin.TabIndex = 2;
            this.lbl_LineJoin.Text = "Line Join:";
            // 
            // lbl_Width
            // 
            this.lbl_Width.AutoSize = true;
            this.lbl_Width.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Width.Location = new System.Drawing.Point(17, 101);
            this.lbl_Width.Name = "lbl_Width";
            this.lbl_Width.Size = new System.Drawing.Size(57, 20);
            this.lbl_Width.TabIndex = 1;
            this.lbl_Width.Text = "Width:";
            // 
            // lbl_DashStyle
            // 
            this.lbl_DashStyle.AutoSize = true;
            this.lbl_DashStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_DashStyle.Location = new System.Drawing.Point(17, 37);
            this.lbl_DashStyle.Name = "lbl_DashStyle";
            this.lbl_DashStyle.Size = new System.Drawing.Size(96, 20);
            this.lbl_DashStyle.TabIndex = 0;
            this.lbl_DashStyle.Text = "Dash Style:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(256, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(544, 450);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pn_Tool);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.pn_Tool.ResumeLayout(false);
            this.pn_Tool.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pn_Tool;
        private System.Windows.Forms.Label lbl_Width;
        private System.Windows.Forms.Label lbl_DashStyle;
        private System.Windows.Forms.Label lbl_EndCap;
        private System.Windows.Forms.Label lbl_StartCap;
        private System.Windows.Forms.Label lbl_DashCap;
        private System.Windows.Forms.Label lbl_LineJoin;
        private System.Windows.Forms.ComboBox cb_Width;
        private System.Windows.Forms.ComboBox cb_DashStyle;
        private System.Windows.Forms.ComboBox cb_EndCap;
        private System.Windows.Forms.ComboBox cb_StartCap;
        private System.Windows.Forms.ComboBox cb_DashCap;
        private System.Windows.Forms.ComboBox cb_LineJoin;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

