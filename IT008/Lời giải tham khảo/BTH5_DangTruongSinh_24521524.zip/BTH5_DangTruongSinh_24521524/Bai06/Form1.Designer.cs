﻿namespace Bai06
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox_Fonts = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // listBox_Fonts
            // 
            this.listBox_Fonts.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBox_Fonts.DrawMode = System.Windows.Forms.DrawMode.OwnerDrawFixed;
            this.listBox_Fonts.FormattingEnabled = true;
            this.listBox_Fonts.ItemHeight = 25;
            this.listBox_Fonts.Location = new System.Drawing.Point(0, 0);
            this.listBox_Fonts.Name = "listBox_Fonts";
            this.listBox_Fonts.Size = new System.Drawing.Size(387, 450);
            this.listBox_Fonts.TabIndex = 0;
            this.listBox_Fonts.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.listBox_Fonts_DrawItem);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(387, 450);
            this.Controls.Add(this.listBox_Fonts);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox listBox_Fonts;
    }
}

