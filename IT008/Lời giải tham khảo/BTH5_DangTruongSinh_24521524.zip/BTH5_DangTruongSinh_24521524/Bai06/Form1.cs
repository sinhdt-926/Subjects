﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai06
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (FontFamily fonts in FontFamily.Families)
            {
                listBox_Fonts.Items.Add(fonts.Name);
            }
        }

        private void listBox_Fonts_DrawItem(object sender, DrawItemEventArgs e)
        {
            if (e.Index < 0) return;
            string fontName = (string)listBox_Fonts.Items[e.Index];
            e.DrawBackground();
            FontStyle fontStyle = FontStyle.Regular;
            float fontSize = 12f;
            Font currentFont;
            try
            {
                currentFont = new Font(fontName, fontSize, fontStyle);
            }
            catch
            {
                currentFont = new Font(FontFamily.GenericSansSerif, fontSize, fontStyle);
            }

            Brush textBrush = (e.State & DrawItemState.Selected) == DrawItemState.Selected ? SystemBrushes.HighlightText : SystemBrushes.ControlText;
            e.Graphics.DrawString(fontName, currentFont, textBrush, e.Bounds);
            e.DrawFocusRectangle();
            currentFont.Dispose();
        }
    }
}
