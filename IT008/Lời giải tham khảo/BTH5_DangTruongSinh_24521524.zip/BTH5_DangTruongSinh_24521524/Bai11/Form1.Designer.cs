﻿namespace Bai11
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.gB_Brushes = new System.Windows.Forms.GroupBox();
            this.rBtn_LinearGradientBrush = new System.Windows.Forms.RadioButton();
            this.rBtn_TextureBrush = new System.Windows.Forms.RadioButton();
            this.rBtn_HatchBrush = new System.Windows.Forms.RadioButton();
            this.rBtn_SolidBrush = new System.Windows.Forms.RadioButton();
            this.gB_Pen = new System.Windows.Forms.GroupBox();
            this.Btn_Color = new System.Windows.Forms.Button();
            this.txt_Width = new System.Windows.Forms.TextBox();
            this.lbl_Width = new System.Windows.Forms.Label();
            this.gB_Shapes = new System.Windows.Forms.GroupBox();
            this.rBtn_Ellipse = new System.Windows.Forms.RadioButton();
            this.rBtn_Rectangle = new System.Windows.Forms.RadioButton();
            this.rBtn_Line = new System.Windows.Forms.RadioButton();
            this.pB_Draw = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.gB_Brushes.SuspendLayout();
            this.gB_Pen.SuspendLayout();
            this.gB_Shapes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Draw)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Info;
            this.panel1.Controls.Add(this.gB_Brushes);
            this.panel1.Controls.Add(this.gB_Pen);
            this.panel1.Controls.Add(this.gB_Shapes);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(218, 490);
            this.panel1.TabIndex = 0;
            // 
            // gB_Brushes
            // 
            this.gB_Brushes.Controls.Add(this.rBtn_LinearGradientBrush);
            this.gB_Brushes.Controls.Add(this.rBtn_TextureBrush);
            this.gB_Brushes.Controls.Add(this.rBtn_HatchBrush);
            this.gB_Brushes.Controls.Add(this.rBtn_SolidBrush);
            this.gB_Brushes.ForeColor = System.Drawing.Color.DodgerBlue;
            this.gB_Brushes.Location = new System.Drawing.Point(12, 279);
            this.gB_Brushes.Name = "gB_Brushes";
            this.gB_Brushes.Size = new System.Drawing.Size(192, 179);
            this.gB_Brushes.TabIndex = 2;
            this.gB_Brushes.TabStop = false;
            this.gB_Brushes.Text = "Brushes";
            // 
            // rBtn_LinearGradientBrush
            // 
            this.rBtn_LinearGradientBrush.AutoSize = true;
            this.rBtn_LinearGradientBrush.ForeColor = System.Drawing.Color.Black;
            this.rBtn_LinearGradientBrush.Location = new System.Drawing.Point(16, 141);
            this.rBtn_LinearGradientBrush.Name = "rBtn_LinearGradientBrush";
            this.rBtn_LinearGradientBrush.Size = new System.Drawing.Size(150, 20);
            this.rBtn_LinearGradientBrush.TabIndex = 3;
            this.rBtn_LinearGradientBrush.TabStop = true;
            this.rBtn_LinearGradientBrush.Text = "LinearGradientBrush";
            this.rBtn_LinearGradientBrush.UseVisualStyleBackColor = true;
            // 
            // rBtn_TextureBrush
            // 
            this.rBtn_TextureBrush.AutoSize = true;
            this.rBtn_TextureBrush.ForeColor = System.Drawing.Color.Black;
            this.rBtn_TextureBrush.Location = new System.Drawing.Point(16, 103);
            this.rBtn_TextureBrush.Name = "rBtn_TextureBrush";
            this.rBtn_TextureBrush.Size = new System.Drawing.Size(107, 20);
            this.rBtn_TextureBrush.TabIndex = 2;
            this.rBtn_TextureBrush.TabStop = true;
            this.rBtn_TextureBrush.Text = "TextureBrush";
            this.rBtn_TextureBrush.UseVisualStyleBackColor = true;
            // 
            // rBtn_HatchBrush
            // 
            this.rBtn_HatchBrush.AutoSize = true;
            this.rBtn_HatchBrush.ForeColor = System.Drawing.Color.Black;
            this.rBtn_HatchBrush.Location = new System.Drawing.Point(16, 65);
            this.rBtn_HatchBrush.Name = "rBtn_HatchBrush";
            this.rBtn_HatchBrush.Size = new System.Drawing.Size(97, 20);
            this.rBtn_HatchBrush.TabIndex = 1;
            this.rBtn_HatchBrush.TabStop = true;
            this.rBtn_HatchBrush.Text = "HatchBrush";
            this.rBtn_HatchBrush.UseVisualStyleBackColor = true;
            // 
            // rBtn_SolidBrush
            // 
            this.rBtn_SolidBrush.AutoSize = true;
            this.rBtn_SolidBrush.ForeColor = System.Drawing.Color.Black;
            this.rBtn_SolidBrush.Location = new System.Drawing.Point(16, 27);
            this.rBtn_SolidBrush.Name = "rBtn_SolidBrush";
            this.rBtn_SolidBrush.Size = new System.Drawing.Size(93, 20);
            this.rBtn_SolidBrush.TabIndex = 0;
            this.rBtn_SolidBrush.TabStop = true;
            this.rBtn_SolidBrush.Text = "SolidBrush";
            this.rBtn_SolidBrush.UseVisualStyleBackColor = true;
            // 
            // gB_Pen
            // 
            this.gB_Pen.Controls.Add(this.Btn_Color);
            this.gB_Pen.Controls.Add(this.txt_Width);
            this.gB_Pen.Controls.Add(this.lbl_Width);
            this.gB_Pen.ForeColor = System.Drawing.Color.DodgerBlue;
            this.gB_Pen.Location = new System.Drawing.Point(12, 155);
            this.gB_Pen.Name = "gB_Pen";
            this.gB_Pen.Size = new System.Drawing.Size(192, 106);
            this.gB_Pen.TabIndex = 1;
            this.gB_Pen.TabStop = false;
            this.gB_Pen.Text = "Pen";
            // 
            // Btn_Color
            // 
            this.Btn_Color.ForeColor = System.Drawing.Color.Black;
            this.Btn_Color.Location = new System.Drawing.Point(57, 68);
            this.Btn_Color.Name = "Btn_Color";
            this.Btn_Color.Size = new System.Drawing.Size(75, 23);
            this.Btn_Color.TabIndex = 2;
            this.Btn_Color.Text = "Color ...";
            this.Btn_Color.UseVisualStyleBackColor = true;
            // 
            // txt_Width
            // 
            this.txt_Width.ForeColor = System.Drawing.Color.Black;
            this.txt_Width.Location = new System.Drawing.Point(68, 24);
            this.txt_Width.Name = "txt_Width";
            this.txt_Width.Size = new System.Drawing.Size(89, 22);
            this.txt_Width.TabIndex = 1;
            this.txt_Width.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl_Width
            // 
            this.lbl_Width.AutoSize = true;
            this.lbl_Width.ForeColor = System.Drawing.Color.Black;
            this.lbl_Width.Location = new System.Drawing.Point(13, 27);
            this.lbl_Width.Name = "lbl_Width";
            this.lbl_Width.Size = new System.Drawing.Size(47, 16);
            this.lbl_Width.TabIndex = 0;
            this.lbl_Width.Text = "Width: ";
            // 
            // gB_Shapes
            // 
            this.gB_Shapes.Controls.Add(this.rBtn_Ellipse);
            this.gB_Shapes.Controls.Add(this.rBtn_Rectangle);
            this.gB_Shapes.Controls.Add(this.rBtn_Line);
            this.gB_Shapes.ForeColor = System.Drawing.Color.DodgerBlue;
            this.gB_Shapes.Location = new System.Drawing.Point(12, 12);
            this.gB_Shapes.Name = "gB_Shapes";
            this.gB_Shapes.Size = new System.Drawing.Size(192, 125);
            this.gB_Shapes.TabIndex = 0;
            this.gB_Shapes.TabStop = false;
            this.gB_Shapes.Text = "Shapes";
            // 
            // rBtn_Ellipse
            // 
            this.rBtn_Ellipse.AutoSize = true;
            this.rBtn_Ellipse.ForeColor = System.Drawing.Color.Black;
            this.rBtn_Ellipse.Location = new System.Drawing.Point(16, 94);
            this.rBtn_Ellipse.Name = "rBtn_Ellipse";
            this.rBtn_Ellipse.Size = new System.Drawing.Size(69, 20);
            this.rBtn_Ellipse.TabIndex = 2;
            this.rBtn_Ellipse.TabStop = true;
            this.rBtn_Ellipse.Text = "Ellipse";
            this.rBtn_Ellipse.UseVisualStyleBackColor = true;
            // 
            // rBtn_Rectangle
            // 
            this.rBtn_Rectangle.AutoSize = true;
            this.rBtn_Rectangle.ForeColor = System.Drawing.Color.Black;
            this.rBtn_Rectangle.Location = new System.Drawing.Point(16, 63);
            this.rBtn_Rectangle.Name = "rBtn_Rectangle";
            this.rBtn_Rectangle.Size = new System.Drawing.Size(90, 20);
            this.rBtn_Rectangle.TabIndex = 1;
            this.rBtn_Rectangle.TabStop = true;
            this.rBtn_Rectangle.Text = "Rectangle";
            this.rBtn_Rectangle.UseVisualStyleBackColor = true;
            // 
            // rBtn_Line
            // 
            this.rBtn_Line.AutoSize = true;
            this.rBtn_Line.ForeColor = System.Drawing.Color.Black;
            this.rBtn_Line.Location = new System.Drawing.Point(16, 32);
            this.rBtn_Line.Name = "rBtn_Line";
            this.rBtn_Line.Size = new System.Drawing.Size(53, 20);
            this.rBtn_Line.TabIndex = 0;
            this.rBtn_Line.TabStop = true;
            this.rBtn_Line.Text = "Line";
            this.rBtn_Line.UseVisualStyleBackColor = true;
            // 
            // pB_Draw
            // 
            this.pB_Draw.BackColor = System.Drawing.Color.White;
            this.pB_Draw.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pB_Draw.Location = new System.Drawing.Point(218, 0);
            this.pB_Draw.Name = "pB_Draw";
            this.pB_Draw.Size = new System.Drawing.Size(709, 490);
            this.pB_Draw.TabIndex = 1;
            this.pB_Draw.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(927, 490);
            this.Controls.Add(this.pB_Draw);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.gB_Brushes.ResumeLayout(false);
            this.gB_Brushes.PerformLayout();
            this.gB_Pen.ResumeLayout(false);
            this.gB_Pen.PerformLayout();
            this.gB_Shapes.ResumeLayout(false);
            this.gB_Shapes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Draw)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.GroupBox gB_Brushes;
        private System.Windows.Forms.GroupBox gB_Pen;
        private System.Windows.Forms.GroupBox gB_Shapes;
        private System.Windows.Forms.RadioButton rBtn_Ellipse;
        private System.Windows.Forms.RadioButton rBtn_Rectangle;
        private System.Windows.Forms.RadioButton rBtn_Line;
        private System.Windows.Forms.Button Btn_Color;
        private System.Windows.Forms.TextBox txt_Width;
        private System.Windows.Forms.Label lbl_Width;
        private System.Windows.Forms.RadioButton rBtn_LinearGradientBrush;
        private System.Windows.Forms.RadioButton rBtn_TextureBrush;
        private System.Windows.Forms.RadioButton rBtn_HatchBrush;
        private System.Windows.Forms.RadioButton rBtn_SolidBrush;
        private System.Windows.Forms.PictureBox pB_Draw;
    }
}

