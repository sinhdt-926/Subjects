﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai11
{
    public partial class Form1 : Form
    {
        private Point startPoint;
        private Point endPoint;
        private bool isDrawing = false;
        private Color penColor = Color.Black;
        private float penWidth = 1;
        private Bitmap drawingBitmap;
        private ColorDialog colorDialog = new ColorDialog();

        private Bitmap textureBitmap;

        public Form1()
        {
            InitializeComponent();
            this.Load += Form1_Load;

            Btn_Color.Click += Btn_Color_Click;

            pB_Draw.MouseDown += pB_Draw_MouseDown;
            pB_Draw.MouseMove += pB_Draw_MouseMove;
            pB_Draw.MouseUp += pB_Draw_MouseUp;
            pB_Draw.Paint += pB_Draw_Paint;

            rBtn_Line.CheckedChanged += Shape_CheckedChanged;
            rBtn_Rectangle.CheckedChanged += Shape_CheckedChanged;
            rBtn_Ellipse.CheckedChanged += Shape_CheckedChanged;
            pB_Draw.Resize += PB_Draw_Resize;

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if (pB_Draw.Width > 0 && pB_Draw.Height > 0)
            {
                drawingBitmap = new Bitmap(pB_Draw.Width, pB_Draw.Height);

                textureBitmap = new Bitmap(8, 8);
                using (Graphics g = Graphics.FromImage(textureBitmap))
                {
                    g.Clear(Color.White);

                    g.FillRectangle(Brushes.Black, 0, 0, 4, 4);
                    g.FillRectangle(Brushes.Black, 4, 4, 4, 4);
                }
            }

            txt_Width.Text = penWidth.ToString();
            rBtn_Line.Checked = true;
            rBtn_SolidBrush.Checked = true;
        }

        private void Btn_Color_Click(object sender, EventArgs e)
        {
            colorDialog.Color = penColor;
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                penColor = colorDialog.Color;
            }
        }

        private void Shape_CheckedChanged(object sender, EventArgs e)
        {
            pB_Draw.Invalidate();
        }

        private void pB_Draw_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                isDrawing = true;
                startPoint = e.Location;
                endPoint = e.Location;
                pB_Draw.Invalidate();
            }
        }

        private void pB_Draw_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDrawing)
            {
                endPoint = e.Location;
                pB_Draw.Invalidate();
            }
        }

        private void pB_Draw_MouseUp(object sender, MouseEventArgs e)
        {
            if (isDrawing && e.Button == MouseButtons.Left)
            {
                isDrawing = false;

                using (Graphics gBitmap = Graphics.FromImage(drawingBitmap))
                {
                    DrawShape(gBitmap, startPoint, endPoint, false);
                }

                pB_Draw.Invalidate();
            }
        }

        private void pB_Draw_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            g.DrawImage(drawingBitmap, 0, 0);

            if (isDrawing)
            {
                DrawShape(g, startPoint, endPoint, true);
            }
        }

        private Pen GetCurrentPen()
        {
            if (!float.TryParse(txt_Width.Text, out penWidth) || penWidth <= 0)
            {
                penWidth = 1;
            }
            return new Pen(penColor, penWidth);
        }

        private Brush GetCurrentBrush(Rectangle rect)
        {
            if (rect.Width == 0 || rect.Height == 0)
                return new SolidBrush(Color.Green);

            if (rBtn_SolidBrush.Checked)
            {
                return new SolidBrush(Color.Green);
            }
            else if (rBtn_HatchBrush.Checked)
            {
                return new HatchBrush(HatchStyle.Horizontal, Color.Blue, Color.Green);
            }
            else if (rBtn_TextureBrush.Checked)
            {
                return new TextureBrush(textureBitmap);
            }
            else if (rBtn_LinearGradientBrush.Checked)
            {
                return new LinearGradientBrush(rect, Color.Red, Color.Green, LinearGradientMode.Vertical);
            }

            return new SolidBrush(Color.Green);
        }

        private Rectangle GetShapeRectangle(Point p1, Point p2)
        {
            int x = Math.Min(p1.X, p2.X);
            int y = Math.Min(p1.Y, p2.Y);
            int width = Math.Abs(p1.X - p2.X);
            int height = Math.Abs(p1.Y - p2.Y);

            return new Rectangle(x, y, width, height);
        }

        private void DrawShape(Graphics g, Point p1, Point p2, bool isTemporary)
        {
            Rectangle rect = GetShapeRectangle(p1, p2);

            if (rBtn_Line.Checked)
            {
                using (Pen pen = GetCurrentPen())
                {
                    g.DrawLine(pen, p1, p2);
                }
                return;
            }

            using (Brush brush = GetCurrentBrush(rect))
            {
                if (rBtn_Rectangle.Checked)
                {
                    g.FillRectangle(brush, rect);
                }
                else if (rBtn_Ellipse.Checked)
                {
                    g.FillEllipse(brush, rect);
                }
            }
        }
        private void PB_Draw_Resize(object sender, EventArgs e)
        {
            if (pB_Draw.Width > 0 && pB_Draw.Height > 0)
            {
                Bitmap newBitmap = new Bitmap(pB_Draw.Width, pB_Draw.Height);
                using (Graphics g = Graphics.FromImage(newBitmap))
                {
                    g.Clear(Color.White);
                    if (drawingBitmap != null)
                        g.DrawImage(drawingBitmap, 0, 0); 
                }
                drawingBitmap = newBitmap;
                pB_Draw.Invalidate();
            }
        }
    }
}
