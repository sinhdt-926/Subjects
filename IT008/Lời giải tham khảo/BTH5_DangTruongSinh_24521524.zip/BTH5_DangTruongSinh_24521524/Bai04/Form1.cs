﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai04
{
    public partial class Form1 : Form
    {
        private readonly ColorDialog colorDialog = new ColorDialog();
        private Color currentColor = Color.Black;

        public Form1()
        {
            InitializeComponent();
            InitializeUI();
        }
        private void InitializeUI()
        {
            LoadSystemFonts();
            LoadFontSizes();
            SetDefaultValues();
            RegisterEvents();
            ApplyTextFormat();
        }

        private void LoadSystemFonts()
        {
            foreach (var font in FontFamily.Families)
                cb_Font.Items.Add(font.Name);
        }

        private void LoadFontSizes()
        {
            int[] sizes = { 8, 10, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48, 72 };
            foreach (int size in sizes)
                cb_Size.Items.Add(size.ToString());
        }

        private void SetDefaultValues()
        {
            cb_Font.Text = "Arial";
            cb_Size.Text = "28";

            checkBox_Bold.Checked = false;
            checkBox_Italic.Checked = false;
            checkBox_Underline.Checked = false;

            tBtn_Center.Checked = true;

            currentColor = Color.DeepPink;
            btn_Color.BackColor = currentColor;
        }

        private void RegisterEvents()
        {
            cb_Font.SelectedIndexChanged += (s, e) => ApplyTextFormat();
            cb_Size.SelectedIndexChanged += (s, e) => ApplyTextFormat();

            checkBox_Bold.CheckedChanged += (s, e) => ApplyTextFormat();
            checkBox_Italic.CheckedChanged += (s, e) => ApplyTextFormat();
            checkBox_Underline.CheckedChanged += (s, e) => ApplyTextFormat();

            rBtn_Left.CheckedChanged += AlignmentChanged;
            tBtn_Center.CheckedChanged += AlignmentChanged;
            rBtn_Right.CheckedChanged += AlignmentChanged;

        }

        private void ApplyTextFormat()
        {
            string fontName = cb_Font.Text;

            float fontSize = float.TryParse(cb_Size.Text, out float size) ? size : 12;

            FontStyle style = FontStyle.Regular;
            if (checkBox_Bold.Checked) 
                style |= FontStyle.Bold;
            if (checkBox_Italic.Checked) 
                style |= FontStyle.Italic;
            if (checkBox_Underline.Checked) 
                style |= FontStyle.Underline;

            try
            {
                txt_Content.Font = new Font(fontName, fontSize, style);
            }
            catch
            {
                MessageBox.Show("Font không hỗ trợ kiểu chữ này!", "Lỗi Font");
            }

            txt_Content.ForeColor = currentColor;
        }
        private void AlignmentChanged(object sender, EventArgs e)
        {
            if (sender is RadioButton rb && rb.Checked)
            {
                if (rBtn_Left.Checked) txt_Content.TextAlign = HorizontalAlignment.Left;
                else if (tBtn_Center.Checked) txt_Content.TextAlign = HorizontalAlignment.Center;
                else if (rBtn_Right.Checked) txt_Content.TextAlign = HorizontalAlignment.Right;
            }
        }
        private void btn_Color_Click(object sender, EventArgs e)
        {
            colorDialog.Color = currentColor;

            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                currentColor = colorDialog.Color;
                btn_Color.BackColor = currentColor;
                ApplyTextFormat();
            }
        }
    }
}
