﻿namespace Bai04
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Font = new System.Windows.Forms.Label();
            this.lbl_Size = new System.Windows.Forms.Label();
            this.lbl_Color = new System.Windows.Forms.Label();
            this.cb_Font = new System.Windows.Forms.ComboBox();
            this.checkBox_Bold = new System.Windows.Forms.CheckBox();
            this.checkBox_Italic = new System.Windows.Forms.CheckBox();
            this.checkBox_Underline = new System.Windows.Forms.CheckBox();
            this.gB_Align_Text = new System.Windows.Forms.GroupBox();
            this.rBtn_Right = new System.Windows.Forms.RadioButton();
            this.tBtn_Center = new System.Windows.Forms.RadioButton();
            this.rBtn_Left = new System.Windows.Forms.RadioButton();
            this.cb_Size = new System.Windows.Forms.ComboBox();
            this.btn_Color = new System.Windows.Forms.Button();
            this.txt_Content = new System.Windows.Forms.TextBox();
            this.gB_Align_Text.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_Font
            // 
            this.lbl_Font.AutoSize = true;
            this.lbl_Font.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Font.Location = new System.Drawing.Point(29, 61);
            this.lbl_Font.Name = "lbl_Font";
            this.lbl_Font.Size = new System.Drawing.Size(42, 20);
            this.lbl_Font.TabIndex = 0;
            this.lbl_Font.Text = "Font";
            // 
            // lbl_Size
            // 
            this.lbl_Size.AutoSize = true;
            this.lbl_Size.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Size.Location = new System.Drawing.Point(366, 64);
            this.lbl_Size.Name = "lbl_Size";
            this.lbl_Size.Size = new System.Drawing.Size(42, 20);
            this.lbl_Size.TabIndex = 1;
            this.lbl_Size.Text = "Size";
            // 
            // lbl_Color
            // 
            this.lbl_Color.AutoSize = true;
            this.lbl_Color.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Color.Location = new System.Drawing.Point(366, 116);
            this.lbl_Color.Name = "lbl_Color";
            this.lbl_Color.Size = new System.Drawing.Size(49, 20);
            this.lbl_Color.TabIndex = 2;
            this.lbl_Color.Text = "Color";
            // 
            // cb_Font
            // 
            this.cb_Font.FormattingEnabled = true;
            this.cb_Font.Location = new System.Drawing.Point(109, 59);
            this.cb_Font.Name = "cb_Font";
            this.cb_Font.Size = new System.Drawing.Size(195, 24);
            this.cb_Font.TabIndex = 3;
            // 
            // checkBox_Bold
            // 
            this.checkBox_Bold.AutoSize = true;
            this.checkBox_Bold.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox_Bold.Location = new System.Drawing.Point(30, 125);
            this.checkBox_Bold.Name = "checkBox_Bold";
            this.checkBox_Bold.Size = new System.Drawing.Size(47, 28);
            this.checkBox_Bold.TabIndex = 4;
            this.checkBox_Bold.Text = "B";
            this.checkBox_Bold.UseVisualStyleBackColor = true;
            // 
            // checkBox_Italic
            // 
            this.checkBox_Italic.AutoSize = true;
            this.checkBox_Italic.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox_Italic.Location = new System.Drawing.Point(83, 125);
            this.checkBox_Italic.Name = "checkBox_Italic";
            this.checkBox_Italic.Size = new System.Drawing.Size(40, 28);
            this.checkBox_Italic.TabIndex = 5;
            this.checkBox_Italic.Text = "I";
            this.checkBox_Italic.UseVisualStyleBackColor = true;
            // 
            // checkBox_Underline
            // 
            this.checkBox_Underline.AutoSize = true;
            this.checkBox_Underline.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBox_Underline.Location = new System.Drawing.Point(134, 125);
            this.checkBox_Underline.Name = "checkBox_Underline";
            this.checkBox_Underline.Size = new System.Drawing.Size(47, 28);
            this.checkBox_Underline.TabIndex = 6;
            this.checkBox_Underline.Text = "U";
            this.checkBox_Underline.UseVisualStyleBackColor = true;
            // 
            // gB_Align_Text
            // 
            this.gB_Align_Text.Controls.Add(this.rBtn_Right);
            this.gB_Align_Text.Controls.Add(this.tBtn_Center);
            this.gB_Align_Text.Controls.Add(this.rBtn_Left);
            this.gB_Align_Text.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gB_Align_Text.Location = new System.Drawing.Point(30, 195);
            this.gB_Align_Text.Name = "gB_Align_Text";
            this.gB_Align_Text.Size = new System.Drawing.Size(190, 177);
            this.gB_Align_Text.TabIndex = 7;
            this.gB_Align_Text.TabStop = false;
            this.gB_Align_Text.Text = "Align Text";
            // 
            // rBtn_Right
            // 
            this.rBtn_Right.AutoSize = true;
            this.rBtn_Right.Location = new System.Drawing.Point(6, 130);
            this.rBtn_Right.Name = "rBtn_Right";
            this.rBtn_Right.Size = new System.Drawing.Size(69, 24);
            this.rBtn_Right.TabIndex = 2;
            this.rBtn_Right.TabStop = true;
            this.rBtn_Right.Text = "Right";
            this.rBtn_Right.UseVisualStyleBackColor = true;
            // 
            // tBtn_Center
            // 
            this.tBtn_Center.AutoSize = true;
            this.tBtn_Center.Location = new System.Drawing.Point(6, 84);
            this.tBtn_Center.Name = "tBtn_Center";
            this.tBtn_Center.Size = new System.Drawing.Size(80, 24);
            this.tBtn_Center.TabIndex = 1;
            this.tBtn_Center.TabStop = true;
            this.tBtn_Center.Text = "Center";
            this.tBtn_Center.UseVisualStyleBackColor = true;
            // 
            // rBtn_Left
            // 
            this.rBtn_Left.AutoSize = true;
            this.rBtn_Left.Location = new System.Drawing.Point(6, 38);
            this.rBtn_Left.Name = "rBtn_Left";
            this.rBtn_Left.Size = new System.Drawing.Size(59, 24);
            this.rBtn_Left.TabIndex = 0;
            this.rBtn_Left.TabStop = true;
            this.rBtn_Left.Text = "Left";
            this.rBtn_Left.UseVisualStyleBackColor = true;
            // 
            // cb_Size
            // 
            this.cb_Size.FormattingEnabled = true;
            this.cb_Size.Location = new System.Drawing.Point(449, 64);
            this.cb_Size.Name = "cb_Size";
            this.cb_Size.Size = new System.Drawing.Size(73, 24);
            this.cb_Size.TabIndex = 8;
            // 
            // btn_Color
            // 
            this.btn_Color.Location = new System.Drawing.Point(449, 115);
            this.btn_Color.Name = "btn_Color";
            this.btn_Color.Size = new System.Drawing.Size(25, 25);
            this.btn_Color.TabIndex = 9;
            this.btn_Color.UseVisualStyleBackColor = true;
            this.btn_Color.Click += new System.EventHandler(this.btn_Color_Click);
            // 
            // txt_Content
            // 
            this.txt_Content.BackColor = System.Drawing.Color.White;
            this.txt_Content.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Content.Location = new System.Drawing.Point(260, 231);
            this.txt_Content.Name = "txt_Content";
            this.txt_Content.Size = new System.Drawing.Size(250, 61);
            this.txt_Content.TabIndex = 10;
            this.txt_Content.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 392);
            this.Controls.Add(this.txt_Content);
            this.Controls.Add(this.btn_Color);
            this.Controls.Add(this.cb_Size);
            this.Controls.Add(this.gB_Align_Text);
            this.Controls.Add(this.checkBox_Underline);
            this.Controls.Add(this.checkBox_Italic);
            this.Controls.Add(this.checkBox_Bold);
            this.Controls.Add(this.cb_Font);
            this.Controls.Add(this.lbl_Color);
            this.Controls.Add(this.lbl_Size);
            this.Controls.Add(this.lbl_Font);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.gB_Align_Text.ResumeLayout(false);
            this.gB_Align_Text.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Font;
        private System.Windows.Forms.Label lbl_Size;
        private System.Windows.Forms.Label lbl_Color;
        private System.Windows.Forms.ComboBox cb_Font;
        private System.Windows.Forms.CheckBox checkBox_Bold;
        private System.Windows.Forms.CheckBox checkBox_Italic;
        private System.Windows.Forms.CheckBox checkBox_Underline;
        private System.Windows.Forms.GroupBox gB_Align_Text;
        private System.Windows.Forms.RadioButton tBtn_Center;
        private System.Windows.Forms.RadioButton rBtn_Left;
        private System.Windows.Forms.RadioButton rBtn_Right;
        private System.Windows.Forms.ComboBox cb_Size;
        private System.Windows.Forms.Button btn_Color;
        private System.Windows.Forms.TextBox txt_Content;
    }
}

