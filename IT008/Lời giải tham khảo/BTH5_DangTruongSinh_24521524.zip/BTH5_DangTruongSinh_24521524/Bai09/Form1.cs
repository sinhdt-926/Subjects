﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai09
{
    public partial class Form1 : Form
    {
        private string selectedShape = "Filled Ellipse";
        private Pen pen = new Pen(Color.Black, 2);
        private Brush brush = new SolidBrush(Color.DarkRed);

        public Form1()
        {
            InitializeComponent();
            cb_Shape.SelectedIndexChanged += (s, e) =>
            {
                selectedShape = cb_Shape.SelectedItem.ToString();
                Invalidate();
            };
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            cb_Shape.Items.AddRange(new object[]
            {
                "Circle", "Square", "Ellipse", "Pie",
                "Filled Circle", "Filled Square", "Filled Ellipse", "Filled Pie"
            });
            cb_Shape.SelectedItem = selectedShape;
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            int padding = 20;
            int top = cb_Shape.Bottom + padding;

            int w = ClientSize.Width - 2 * padding;
            int h = ClientSize.Height - top - padding;
            if (w <= 0 || h <= 0) return;

            int size = (int)(Math.Min(w, h) * 0.3);

            Rectangle R = new Rectangle((ClientSize.Width - size * 2) / 2, top + (ClientSize.Height - top - size * 2) / 2, size * 2, size * 2);
            Rectangle RE = new Rectangle((ClientSize.Width - (int)(w * 0.4)) / 2, top + (ClientSize.Height - top - (int)(h * 0.5)) / 2, (int)(w * 0.45), (int)(h * 0.4));

            switch (selectedShape)
            {
                case "Circle":
                    g.DrawEllipse(pen, R);
                    break;
                case "Square":
                    g.DrawRectangle(pen, R);
                    break;
                case "Ellipse":
                    g.DrawEllipse(pen, RE);
                    break;
                case "Pie":
                    g.DrawPie(pen, R, 0, 270);
                    break;

                case "Filled Circle":
                    g.FillEllipse(brush, R);
                    break;
                case "Filled Square":
                    g.FillRectangle(brush, R);
                    break;
                case "Filled Ellipse":
                    g.FillEllipse(brush, RE);
                    break;
                case "Filled Pie":
                    g.FillPie(brush, R, 0, 270);
                    break;
            }
        }
    }
}