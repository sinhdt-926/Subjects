﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai08
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
            timer.Start();
        }
        private void timer_Tick(object sender, EventArgs e)
        {
            this.Invalidate();
        }
        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = SmoothingMode.AntiAlias;

            int w = this.ClientSize.Width;
            int h = this.ClientSize.Height;

            int radius = Math.Min(w, h) / 2 - 20;
            Point center = new Point(w / 2, h / 2);

            Pen pen = new Pen(Color.White, 2);
            Brush white = Brushes.White;

            for (int i = 0; i < 60; i++)
            {
                double angle = i * 6 * Math.PI / 180;
                int dotRadius = (i % 5 == 0) ? 6 : 3;

                int x = center.X + (int)(Math.Cos(angle) * radius);
                int y = center.Y + (int)(Math.Sin(angle) * radius);

                g.FillEllipse(white, x - dotRadius, y - dotRadius, dotRadius * 2, dotRadius * 2);
            }

            DateTime now = DateTime.Now;

            float secAngle = now.Second * 6;
            float minAngle = now.Minute * 6 + now.Second * 0.1f;
            float hourAngle = (now.Hour % 12) * 30 + now.Minute * 0.5f;

            DrawPolygonHand(g, center, hourAngle, length: radius * 0.45f, backLength: radius * 0.15f, thickness: 12);
            DrawPolygonHand(g, center, minAngle, length: radius * 0.70f, backLength: radius * 0.20f, thickness: 7);
            DrawStraightHand(g, center, secAngle, length: radius * 0.90f, width: 1);

            g.FillEllipse(Brushes.White, center.X - 4, center.Y - 4, 8, 8);
        }
        private void DrawPolygonHand(Graphics g, Point center, float angle,
            float length, float backLength, float thickness)
        {
            angle -= 90;
            double rad = angle * Math.PI / 180;

            double cosA = Math.Cos(rad);
            double sinA = Math.Sin(rad);

            PointF tip = new PointF(center.X + (float)(cosA * length), center.Y + (float)(sinA * length));
            PointF side1 = new PointF(center.X + (float)(-sinA * thickness), center.Y + (float)(cosA * thickness));
            PointF side2 = new PointF(center.X + (float)(sinA * thickness), center.Y + (float)(-cosA * thickness));
            PointF back = new PointF(center.X - (float)(cosA * backLength), center.Y - (float)(sinA * backLength));
            
            PointF[] poly = {side1, tip, side2, back};
            g.DrawPolygon(new Pen(Color.White, 1), poly);
        }
        private void DrawStraightHand(Graphics g, Point center, float angle, float length, int width)
        {
            angle -= 90;
            double rad = angle * Math.PI / 180;

            int x = center.X + (int)(Math.Cos(rad) * length);
            int y = center.Y + (int)(Math.Sin(rad) * length);

            g.DrawLine(new Pen(Color.White, width), center, new Point(x, y));
        }
    }
}
