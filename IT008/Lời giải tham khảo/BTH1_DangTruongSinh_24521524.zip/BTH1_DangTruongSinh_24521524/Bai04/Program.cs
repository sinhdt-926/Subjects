﻿using System;
using System.Text;


namespace BTH1_Bai04
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;

            int month = NhapSoNguyen("tháng");
            int year = NhapSoNguyen("năm");

            if (IsValidMonth(month) && IsValidYear(year))
            {
                int days = DateTime.DaysInMonth(year, month);
                Console.WriteLine($"Tháng {month}/{year} có {days} ngày.");
            }
            else
            {
                Console.WriteLine($"Tháng {month}/{year} không hợp lệ!");
            }
        }

        static int NhapSoNguyen(string tenTruong)
        {
            int value;
            while (true)
            {
                Console.Write($"Nhập {tenTruong}: ");
                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine($"Bạn chưa nhập {tenTruong}, vui lòng nhập lại!");
                    continue;
                }

                if (double.TryParse(input, out double dbl))
                {
                    if (dbl % 1 != 0)
                    {
                        Console.WriteLine($"Bạn đã nhập số thập phân ({dbl}), vui lòng nhập số nguyên!");
                        continue;
                    }
                }

                if (int.TryParse(input, out value))
                {
                    break; 
                }
                else
                {
                    Console.WriteLine($"Giá trị '{input}' không hợp lệ, vui lòng nhập số nguyên!");
                }
            }
            return value;
        }

        static bool IsValidMonth(int month)
        {
            return month >= 1 && month <= 12;
        }
        static bool IsValidYear(int year)
        {
            return year >= 1 && year <= 9999;
        }
    }
}