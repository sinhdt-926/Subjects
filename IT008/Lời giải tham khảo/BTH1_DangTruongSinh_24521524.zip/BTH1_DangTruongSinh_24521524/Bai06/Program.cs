﻿using System;
using System.Text;
using System.Globalization;

namespace BTH1_Bai06
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            Console.WriteLine("=== NHẬP KÍCH THƯỚC CỦA MA TRẬN ===");

            int n = NhapSoNguyen("số dòng", 1);
            int m = NhapSoNguyen("số cột", 1);

            int[,] matrix = new int[n, m];
            ImportMatrix(matrix, n, m);
            Choose(matrix, ref n, ref m);
        }

        //HÀM NHẬP CHUNG

        static int NhapSoNguyen(string tenTruong, int minValue = int.MinValue)
        {
            int value;
            while (true)
            {
                Console.Write($"Nhập {tenTruong}: ");
                string input = Console.ReadLine();

                // Kiểm tra rỗng
                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine($"Bạn chưa nhập {tenTruong}, vui lòng nhập lại!");
                    continue;
                }

                // Kiểm tra số thực
                if (double.TryParse(input, NumberStyles.Float, CultureInfo.InvariantCulture, out double dbl))
                {
                    if (dbl % 1 != 0)
                    {
                        Console.WriteLine($"Bạn đã nhập số thập phân ({dbl}), vui lòng nhập số nguyên!");
                        continue;
                    }
                }

                // Kiểm tra số nguyên
                if (int.TryParse(input, out value))
                {
                    if (value < minValue)
                    {
                        Console.WriteLine($"{tenTruong} phải ≥ {minValue}, vui lòng nhập lại!");
                        continue;
                    }
                    return value;
                }
                else
                {
                    Console.WriteLine($"Giá trị '{input}' không hợp lệ, vui lòng nhập số nguyên!");
                }
            }
        }

        //KIỂM TRA MA TRẬN RỖNG
        static bool IsMatrixEmpty(int n, int m)
        {
            return n <= 0 || m <= 0;
        }

        static void Menu()
        {
            Console.WriteLine("\t----- MENU -----");
            Console.WriteLine("1. Xuất ma trận.");
            Console.WriteLine("2. Phần tử lớn nhất / nhỏ nhất.");
            Console.WriteLine("3. Dòng có tổng lớn nhất.");
            Console.WriteLine("4. Tổng các số không phải là số nguyên tố.");
            Console.WriteLine("5. Xoá dòng thứ k.");
            Console.WriteLine("6. Xoá cột chứa phần tử lớn nhất.");
            Console.WriteLine("0. Thoát!");
        }

        static void Choose(int[,] matrix, ref int n, ref int m)
        {
            while (true)
            {
                Console.Clear();
                Menu();
                int choice = NhapSoNguyen("lựa chọn menu", 0);

                switch (choice)
                {
                    case 0:
                        Console.WriteLine("Đã thoát chương trình.");
                        return;

                    case 1:
                        if (IsMatrixEmpty(n, m))
                        {
                            Console.WriteLine("Ma trận hiện đang trống, không thể xuất!");
                            break;
                        }
                        Console.WriteLine("Ma trận:");
                        OutputMatrix(matrix, n, m);
                        break;

                    case 2:
                        if (IsMatrixEmpty(n, m))
                        {
                            Console.WriteLine("Ma trận trống, không thể tìm phần tử lớn nhất / nhỏ nhất!");
                            break;
                        }
                        OutputMatrix(matrix, n, m);
                        Console.WriteLine($"Phần tử lớn nhất: {Max_Element(matrix, n, m)}");
                        Console.WriteLine($"Phần tử nhỏ nhất: {Min_Element(matrix, n, m)}");
                        break;

                    case 3:
                        if (IsMatrixEmpty(n, m))
                        {
                            Console.WriteLine("Ma trận trống, không thể tìm dòng có tổng lớn nhất!");
                            break;
                        }
                        OutputMatrix(matrix, n, m);
                        Console.WriteLine($"Dòng có tổng lớn nhất là dòng: {Find_MaxLine(matrix, n, m)}");
                        break;

                    case 4:
                        if (IsMatrixEmpty(n, m))
                        {
                            Console.WriteLine("Ma trận trống, không thể tính tổng các số không phải số nguyên tố!");
                            break;
                        }
                        OutputMatrix(matrix, n, m);
                        Console.WriteLine($"Tổng các số không phải số nguyên tố: {Sum_NotPrime(matrix, n, m)}");
                        break;

                    case 5:
                        if (IsMatrixEmpty(n, m))
                        {
                            Console.WriteLine("Ma trận trống, không thể xoá dòng!");
                            break;
                        }
                        OutputMatrix(matrix, n, m);
                        int k = NhapSoNguyen($"chỉ số dòng cần xoá (1–>{n})", 1);
                        Delete_Row(matrix, ref n, m, k);
                        OutputMatrix(matrix, n, m);
                        break;

                    case 6:
                        if (IsMatrixEmpty(n, m))
                        {
                            Console.WriteLine("Ma trận trống, không thể xoá cột!");
                            break;
                        }
                        OutputMatrix(matrix, n, m);
                        Delete_MaxValueColumn(matrix, n, ref m);
                        OutputMatrix(matrix, n, m);
                        break;

                    default:
                        Console.WriteLine("Lựa chọn không hợp lệ, vui lòng nhập lại!");
                        break;
                }
                Console.ReadKey();
            }
        }

        // ======= XỬ LÝ MA TRẬN =======

        static void ImportMatrix(int[,] matrix, int n, int m)
        {
            Random rnd = new Random();
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    matrix[i, j] = rnd.Next(-100, 100);
        }

        static void OutputMatrix(int[,] matrix, int n, int m)
        {
            Console.WriteLine();
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                    Console.Write($"{matrix[i, j],5}");
                Console.WriteLine();
            }
        }

        static int Max_Element(int[,] matrix, int n, int m)
        {
            int max = matrix[0, 0];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    if (matrix[i, j] > max)
                        max = matrix[i, j];
            return max;
        }

        static int Min_Element(int[,] matrix, int n, int m)
        {
            int min = matrix[0, 0];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    if (matrix[i, j] < min)
                        min = matrix[i, j];
            return min;
        }

        static int Find_MaxLine(int[,] matrix, int n, int m)
        {
            int maxSum = int.MinValue, index = 0;
            for (int i = 0; i < n; i++)
            {
                int sum = 0;
                for (int j = 0; j < m; j++)
                    sum += matrix[i, j];

                if (sum > maxSum)
                {
                    maxSum = sum;
                    index = i;
                }
            }
            return index + 1;
        }

        static bool IsPrime(int x)
        {
            if (x < 2) return false;
            for (int i = 2; i <= Math.Sqrt(x); i++)
                if (x % i == 0) return false;
            return true;
        }

        static int Sum_NotPrime(int[,] matrix, int n, int m)
        {
            int sum = 0;
            for (int i = 0; i < n; i++)
                for (int j = 0; j < m; j++)
                    if (!IsPrime(matrix[i, j]))
                        sum += matrix[i, j];
            return sum;
        }

        static void Delete_Row(int[,] matrix, ref int n, int m, int k)
        {
            if (k < 1 || k > n)
            {
                Console.WriteLine($"Dòng {k} không tồn tại!");
                return;
            }

            for (int i = k - 1; i < n - 1; i++)
                for (int j = 0; j < m; j++)
                    matrix[i, j] = matrix[i + 1, j];

            n--;
            Console.WriteLine($"Đã xoá dòng {k} thành công.");
        }

        static void Delete_MaxValueColumn(int[,] matrix, int n, ref int m)
        {
            int max = Max_Element(matrix, n, m);
            int colIndex = -1;

            for (int i = 0; i < n && colIndex == -1; i++)
                for (int j = 0; j < m; j++)
                    if (matrix[i, j] == max)
                    {
                        colIndex = j;
                        break;
                    }

            if (colIndex == -1)
            {
                Console.WriteLine("Không tìm thấy phần tử lớn nhất để xoá.");
                return;
            }

            for (int j = colIndex; j < m - 1; j++)
                for (int i = 0; i < n; i++)
                    matrix[i, j] = matrix[i, j + 1];

            m--;
            Console.WriteLine($"Đã xoá cột {colIndex + 1} (chứa phần tử lớn nhất {max}).");
        }
    }
}
