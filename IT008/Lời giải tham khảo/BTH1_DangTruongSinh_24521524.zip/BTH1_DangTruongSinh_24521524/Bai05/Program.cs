﻿using System;
using System.Text;
namespace BTH1_Bai05
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            int day = NhapSoNguyen("ngày");
            int month = NhapSoNguyen("tháng");
            int year = NhapSoNguyen("năm");
            if (IsValidDay(day, month, year))
            {
                DateTime dateTime = new DateTime(year, month, day);
                Console.WriteLine($"{day}/{month}/{year} là {getDayOfWeek(dateTime.DayOfWeek)}");
            }
            else 
                Console.WriteLine($"{day}/{month}/{year} không hợp lệ");

        }
        static int NhapSoNguyen(string tenTruong)
        {
            int value;
            while (true)
            {
                Console.Write($"Nhập {tenTruong}: ");
                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine($"Bạn chưa nhập {tenTruong}, vui lòng nhập lại!");
                    continue;
                }

                if (double.TryParse(input, out double dbl))
                {
                    if (dbl % 1 != 0)
                    {
                        Console.WriteLine($"Bạn đã nhập số thập phân ({dbl}), vui lòng nhập số nguyên!");
                        continue;
                    }
                }

                if (int.TryParse(input, out value))
                {
                    break;
                }
                else
                {
                    Console.WriteLine($"Giá trị '{input}' không hợp lệ, vui lòng nhập số nguyên!");
                }
            }
            return value;
        }

        // Kiểm tra ngày có hợp lệ
        static bool IsValidDay(int day, int month, int year)
        {
            if (day < 1) return false;
            if (year < 1 || year > 9999) return false;
            if (month < 1 || month > 12) return false; 
            int[] DayInMonth = { 31, DateTime.IsLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
            if (day > DayInMonth[month - 1]) return false;
            return true;
        }

        // Chuyển thứ trong tuần sang tiếng Việt
        static string getDayOfWeek(DayOfWeek date)
        {
            int dayOfWeek = (int) date;
            switch (dayOfWeek)
            {
                case 0:
                    return "Chủ Nhật";
                case 1:
                    return "Thứ Hai";
                case 2:
                    return "Thứ Ba";
                case 3:
                    return "Thứ Tư";
                case 4:
                    return "Thứ Năm";
                case 5:
                    return "Thứ Sáu";
                case 6:
                    return "Thứ Bảy";
                default: return "";
            }
        }
    }
}