﻿using System;
using System.Text;
using System.Globalization;

namespace BTH1_Bai02
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Unicode;
            int n;

            while (true)
            {
                Console.Write("Nhập n (n > 0): ");
                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Bạn chưa nhập gì, vui lòng nhập một số nguyên dương!");
                    continue;
                }

                if (double.TryParse(input, out double doubleValue))
                {
                    if (doubleValue % 1 != 0)
                    {
                        Console.WriteLine("Bạn đã nhập số thập phân ({0}), vui lòng nhập số nguyên dương!", doubleValue);
                        continue;
                    }
                }

                if (int.TryParse(input, out n))
                {
                    if (n <= 0)
                    {
                        Console.WriteLine("Số bạn nhập là {0} (≤ 0), vui lòng nhập số nguyên dương!", n);
                        continue;
                    }
                    break;
                }
                else
                {
                    Console.WriteLine("Giá trị bạn nhập không hợp lệ, vui lòng nhập số nguyên dương!");
                }
            }

            int sum = PrintAndSumPrimes(n);
            Console.WriteLine("\nTổng các số nguyên tố < {0}: {1}", n, sum);
        }

        static bool isPrime(int x)
        {
            if (x < 2) return false;
            for (int i = 2; i <= Math.Sqrt(x); i++)
            {
                if (x % i == 0) return false;
            }
            return true;
        }

        static int PrintAndSumPrimes(int n)
        {
            int sum = 0;
            Console.Write("Các số nguyên tố < {0}: ", n);
            for (int i = 2; i < n; i++)
            {
                if (isPrime(i))
                {
                    Console.Write(i + " ");
                    sum += i;
                }
            }
            return sum;
        }
    }
}
