﻿using System;
using System.Text;

namespace BTH1_Bai01
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Unicode;
            int n = 0;
            while (true)
            {
                Console.Write("Nhập kích thước của mảng (n > 0): ");
                string input = Console.ReadLine();

                // Kiểm tra dữ liệu nhập vào
                if (!int.TryParse(input, out n))
                {
                    Console.WriteLine("Bạn phải nhập một số nguyên!");
                    continue;
                }

                if (n <= 0)
                {
                    Console.WriteLine("Kích thước mảng phải lớn hơn 0!");
                    continue;
                }
                break;
            }

            int[] a = new int[n];
            ArrayImport(a, n);
            Menu();
            Choose(a, n);
        }

        static void ArrayImport(int[] a, int n)
        {
            Random random = new Random();
            for (int i = 0; i < n; i++)
                a[i] = random.Next(-100, 100);
            Console.Write("Mảng vừa tạo: ");
            for (int i = 0; i < n; i++)
                Console.Write(a[i] + " ");
            Console.WriteLine();
        }

        // Tính tổng các số lẻ trong mảng
        static int OddTotal(int[] a, int n)
        {
            int sum = 0;
            for (int i = 0; i < n; i++)
            {
                if (a[i] % 2 != 0)
                    sum += a[i];
            }
            return sum;
        }

        // Đếm số nguyên tố có trong mảng
        static int CountPrime(int[] a, int n)
        {
            bool isPrime(int x)
            {
                if (x < 2) return false;
                for (int i = 2; i <= Math.Sqrt(x); i++)
                {
                    if (x % i == 0) return false;
                }
                return true;
            }

            int count = 0;
            for (int i = 0; i < n; i++)
            {
                if (isPrime(a[i]))
                    count++;
            }
            return count;
        }

        // Tìm số chính phương nhỏ nhất trong mảng
        static int FindMinSquareNumber(int[] a, int n)
        {
            bool isSquareNumber(int x)
            {
                if (x < 0) return false;
                int temp = (int)Math.Sqrt(x);
                return temp * temp == x;
            }

            int min = int.MaxValue;
            bool found = false;

            for (int i = 0; i < n; i++)
            {
                if (isSquareNumber(a[i]) && a[i] < min)
                {
                    min = a[i];
                    found = true;
                }
            }

            return found ? min : -1;
        }

        static void Menu()
        {
            Console.WriteLine("\n-------MENU-------");
            Console.WriteLine("1. Tính tổng các số lẻ trong mảng");
            Console.WriteLine("2. Đếm số nguyên tố trong mảng");
            Console.WriteLine("3. Tìm số chính phương nhỏ nhất trong mảng");
            Console.WriteLine("4. Thoát!");
        }

        static void Choose(int[] a, int n)
        {
            Console.Write("\nNhập lựa chọn của bạn: ");
            string input = Console.ReadLine();
            int choice;

            // Kiểm tra lựa chọn hợp lệ
            if (!int.TryParse(input, out choice))
            {
                Console.WriteLine("Bạn phải nhập số nguyên trong menu!");
                Choose(a, n);
                return;
            }

            switch (choice)
            {
                case 1:
                    Console.WriteLine("Tổng các số lẻ trong mảng: " + OddTotal(a, n));
                    Choose(a, n);
                    break;
                case 2:
                    Console.WriteLine("Số lượng các số nguyên tố trong mảng: " + CountPrime(a, n));
                    Choose(a, n);
                    break;
                case 3:
                    int minSquare = FindMinSquareNumber(a, n);
                    if (minSquare == -1)
                        Console.WriteLine("Không có số chính phương trong mảng.");
                    else
                        Console.WriteLine("Số chính phương nhỏ nhất trong mảng: " + minSquare);
                    Choose(a, n);
                    break;
                case 4:
                    Console.WriteLine("Đã thoát chương trình!");
                    return;
                default:
                    Console.WriteLine("Lựa chọn không hợp lệ!");
                    Choose(a, n);
                    break;
            }
        }
    }
}
