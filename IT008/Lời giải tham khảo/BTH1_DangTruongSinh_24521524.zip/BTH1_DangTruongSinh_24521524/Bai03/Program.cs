﻿using System;
using System.Text;
using System.Globalization;

namespace BTH1_Bai03
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Unicode;

            int day = NhapSoNguyen("ngày");
            int month = NhapSoNguyen("tháng");
            int year = NhapSoNguyen("năm");

            if (IsValidDay(day, month, year))
                Console.WriteLine($"{day}/{month}/{year} là ngày hợp lệ");
            else
                Console.WriteLine($"{day}/{month}/{year} không phải là ngày hợp lệ");
        }

        static int NhapSoNguyen(string tenTruong)
        {
            int value;
            while (true)
            {
                Console.Write($"Nhập {tenTruong}: ");
                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine($"Bạn chưa nhập {tenTruong}, vui lòng nhập lại!");
                    continue;
                }

                if (double.TryParse(input, out double dbl))
                {
                    if (dbl % 1 != 0)
                    {
                        Console.WriteLine($"Bạn đã nhập số thập phân ({dbl}), vui lòng nhập số nguyên!");
                        continue;
                    }
                }

                if (int.TryParse(input, out value))
                {
                    break; 
                }
                else
                {
                    Console.WriteLine($"Giá trị '{input}' không hợp lệ, vui lòng nhập số nguyên!");
                }
            }
            return value;
        }

        static bool IsValidDay(int day, int month, int year)
        {
            if (year <= 0) return false;
            if (month < 1 || month > 12) return false;
            if (day < 1) return false;

            int[] DayInMonth =
            {
                31, DateTime.IsLeapYear(year) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
            };

            if (day > DayInMonth[month - 1])
                return false;

            return true;
        }
    }
}
