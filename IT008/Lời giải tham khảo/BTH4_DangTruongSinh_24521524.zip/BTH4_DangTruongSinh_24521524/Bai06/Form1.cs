﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai06
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            toolTip1.SetToolTip(txtNguon, "Đường dẫn file nguồn");
            toolTip1.SetToolTip(txtDich, "Đường dẫn thư mục đích");
            toolTip1.SetToolTip(btnSaoChep, "Sao chép tập tin");
        }

        // Chọn file nguồn
        private void btnThuMucNguon_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Title = "Chọn 1 tập tin cần sao chép";

            if (dlg.ShowDialog() == DialogResult.OK)
                txtNguon.Text = dlg.FileName;
        }

        // Chọn thư mục đích
        private void btnThuMucDich_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog dlg = new FolderBrowserDialog();
            dlg.Description = "Chọn thư mục đích";

            if (dlg.ShowDialog() == DialogResult.OK)
                txtDich.Text = dlg.SelectedPath;
        }

        // Sao chép 1 tập tin (đúng yêu cầu đề bài)
        private void btnSaoChep_Click(object sender, EventArgs e)
        {
            string srcFile = txtNguon.Text;
            string dstFolder = txtDich.Text;

            // Kiểm tra file nguồn
            if (!File.Exists(srcFile))
            {
                MessageBox.Show("File nguồn không tồn tại!");
                return;
            }

            // Kiểm tra thư mục đích
            if (!Directory.Exists(dstFolder))
                Directory.CreateDirectory(dstFolder);

            string fileName = Path.GetFileName(srcFile);
            string destFile = Path.Combine(dstFolder, fileName);

            progressBarTienTrinh.Value = 0;
            progressBarTienTrinh.Maximum = 100;

            lblCopy.Visible = true;
            lblCopy.Text = "Đang sao chép: " + fileName;

            // Sao chép file và cập nhật progress
            byte[] buffer = new byte[1024 * 1024];
            long totalBytes = new FileInfo(srcFile).Length;
            long copiedBytes = 0;

            using (FileStream fsSrc = new FileStream(srcFile, FileMode.Open, FileAccess.Read))
            using (FileStream fsDst = new FileStream(destFile, FileMode.Create, FileAccess.Write))
            {
                int read;
                while ((read = fsSrc.Read(buffer, 0, buffer.Length)) > 0)
                {
                    fsDst.Write(buffer, 0, read);
                    copiedBytes += read;

                    int percent = (int)((copiedBytes * 100) / totalBytes);
                    progressBarTienTrinh.Value = percent;

                    Application.DoEvents();
                }
            }

            lblCopy.Text = "Hoàn tất sao chép.";
            MessageBox.Show("Sao chép thành công!");
        }
    }
}