﻿namespace Bai06
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.gbSaoChep = new System.Windows.Forms.GroupBox();
            this.btnSaoChep = new System.Windows.Forms.Button();
            this.btnThuMucDich = new System.Windows.Forms.Button();
            this.btnThuMucNguon = new System.Windows.Forms.Button();
            this.txtDich = new System.Windows.Forms.TextBox();
            this.txtNguon = new System.Windows.Forms.TextBox();
            this.lblDich = new System.Windows.Forms.Label();
            this.lblNguon = new System.Windows.Forms.Label();
            this.gbTienTrinhSaoChep = new System.Windows.Forms.GroupBox();
            this.progressBarTienTrinh = new System.Windows.Forms.ProgressBar();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.lblCopy = new System.Windows.Forms.Label();
            this.gbSaoChep.SuspendLayout();
            this.gbTienTrinhSaoChep.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbSaoChep
            // 
            this.gbSaoChep.Controls.Add(this.btnSaoChep);
            this.gbSaoChep.Controls.Add(this.btnThuMucDich);
            this.gbSaoChep.Controls.Add(this.btnThuMucNguon);
            this.gbSaoChep.Controls.Add(this.txtDich);
            this.gbSaoChep.Controls.Add(this.txtNguon);
            this.gbSaoChep.Controls.Add(this.lblDich);
            this.gbSaoChep.Controls.Add(this.lblNguon);
            this.gbSaoChep.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbSaoChep.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.gbSaoChep.Location = new System.Drawing.Point(12, 12);
            this.gbSaoChep.Name = "gbSaoChep";
            this.gbSaoChep.Size = new System.Drawing.Size(840, 243);
            this.gbSaoChep.TabIndex = 0;
            this.gbSaoChep.TabStop = false;
            this.gbSaoChep.Text = "Sao chép tập tin";
            // 
            // btnSaoChep
            // 
            this.btnSaoChep.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSaoChep.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnSaoChep.Location = new System.Drawing.Point(305, 178);
            this.btnSaoChep.Name = "btnSaoChep";
            this.btnSaoChep.Size = new System.Drawing.Size(195, 41);
            this.btnSaoChep.TabIndex = 6;
            this.btnSaoChep.Text = "Sao chép";
            this.btnSaoChep.UseVisualStyleBackColor = true;
            this.btnSaoChep.Click += new System.EventHandler(this.btnSaoChep_Click);
            // 
            // btnThuMucDich
            // 
            this.btnThuMucDich.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThuMucDich.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnThuMucDich.Location = new System.Drawing.Point(744, 100);
            this.btnThuMucDich.Name = "btnThuMucDich";
            this.btnThuMucDich.Size = new System.Drawing.Size(45, 30);
            this.btnThuMucDich.TabIndex = 5;
            this.btnThuMucDich.Text = "...";
            this.btnThuMucDich.UseVisualStyleBackColor = true;
            this.btnThuMucDich.Click += new System.EventHandler(this.btnThuMucDich_Click);
            // 
            // btnThuMucNguon
            // 
            this.btnThuMucNguon.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThuMucNguon.ForeColor = System.Drawing.SystemColors.InfoText;
            this.btnThuMucNguon.Location = new System.Drawing.Point(744, 51);
            this.btnThuMucNguon.Name = "btnThuMucNguon";
            this.btnThuMucNguon.Size = new System.Drawing.Size(45, 30);
            this.btnThuMucNguon.TabIndex = 4;
            this.btnThuMucNguon.Text = "...";
            this.btnThuMucNguon.UseVisualStyleBackColor = true;
            this.btnThuMucNguon.Click += new System.EventHandler(this.btnThuMucNguon_Click);
            // 
            // txtDich
            // 
            this.txtDich.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDich.Location = new System.Drawing.Point(305, 100);
            this.txtDich.Name = "txtDich";
            this.txtDich.Size = new System.Drawing.Size(424, 24);
            this.txtDich.TabIndex = 3;
            // 
            // txtNguon
            // 
            this.txtNguon.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNguon.Location = new System.Drawing.Point(305, 57);
            this.txtNguon.Name = "txtNguon";
            this.txtNguon.Size = new System.Drawing.Size(424, 24);
            this.txtNguon.TabIndex = 2;
            // 
            // lblDich
            // 
            this.lblDich.AutoSize = true;
            this.lblDich.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDich.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblDich.Location = new System.Drawing.Point(39, 105);
            this.lblDich.Name = "lblDich";
            this.lblDich.Size = new System.Drawing.Size(204, 22);
            this.lblDich.TabIndex = 1;
            this.lblDich.Text = "Đường dẫn thư mục đích";
            // 
            // lblNguon
            // 
            this.lblNguon.AutoSize = true;
            this.lblNguon.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNguon.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblNguon.Location = new System.Drawing.Point(39, 54);
            this.lblNguon.Name = "lblNguon";
            this.lblNguon.Size = new System.Drawing.Size(221, 22);
            this.lblNguon.TabIndex = 0;
            this.lblNguon.Text = "Đường dẫn thư mục nguồn";
            // 
            // gbTienTrinhSaoChep
            // 
            this.gbTienTrinhSaoChep.Controls.Add(this.progressBarTienTrinh);
            this.gbTienTrinhSaoChep.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbTienTrinhSaoChep.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.gbTienTrinhSaoChep.Location = new System.Drawing.Point(12, 277);
            this.gbTienTrinhSaoChep.Name = "gbTienTrinhSaoChep";
            this.gbTienTrinhSaoChep.Size = new System.Drawing.Size(840, 85);
            this.gbTienTrinhSaoChep.TabIndex = 1;
            this.gbTienTrinhSaoChep.TabStop = false;
            this.gbTienTrinhSaoChep.Text = "Tiến trình sao chép";
            // 
            // progressBarTienTrinh
            // 
            this.progressBarTienTrinh.Location = new System.Drawing.Point(26, 31);
            this.progressBarTienTrinh.Name = "progressBarTienTrinh";
            this.progressBarTienTrinh.Size = new System.Drawing.Size(790, 36);
            this.progressBarTienTrinh.TabIndex = 0;
            // 
            // lblCopy
            // 
            this.lblCopy.AutoSize = true;
            this.lblCopy.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCopy.Location = new System.Drawing.Point(8, 382);
            this.lblCopy.Name = "lblCopy";
            this.lblCopy.Size = new System.Drawing.Size(141, 22);
            this.lblCopy.TabIndex = 2;
            this.lblCopy.Text = "Đang sao chép: ";
            this.lblCopy.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(864, 411);
            this.Controls.Add(this.lblCopy);
            this.Controls.Add(this.gbTienTrinhSaoChep);
            this.Controls.Add(this.gbSaoChep);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.gbSaoChep.ResumeLayout(false);
            this.gbSaoChep.PerformLayout();
            this.gbTienTrinhSaoChep.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox gbSaoChep;
        private System.Windows.Forms.GroupBox gbTienTrinhSaoChep;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label lblCopy;
        private System.Windows.Forms.Button btnSaoChep;
        private System.Windows.Forms.Button btnThuMucDich;
        private System.Windows.Forms.Button btnThuMucNguon;
        private System.Windows.Forms.TextBox txtDich;
        private System.Windows.Forms.TextBox txtNguon;
        private System.Windows.Forms.Label lblDich;
        private System.Windows.Forms.Label lblNguon;
        private System.Windows.Forms.ProgressBar progressBarTienTrinh;
    }
}

