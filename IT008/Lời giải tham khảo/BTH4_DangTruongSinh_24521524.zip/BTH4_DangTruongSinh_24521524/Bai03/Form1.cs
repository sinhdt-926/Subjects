﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
          private void Form1_Load(object sender, EventArgs e)
        {
            ShowDateTime();
        }      
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "AVI file|*.avi|MPEG File|*.mpeg|WAV File|*.wav|MIDI File|*.midi|MP4 File|*.mp4|MP3 File|*.mp3";

            if (dlg.ShowDialog() == DialogResult.OK)
            {
                WMPlayer.URL = dlg.FileName;
            }
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ShowDateTime();
        }
        private void ShowDateTime ()
        {
            StatuslblDateTime.Text = $"Hôm nay là ngày: {DateTime.Now.ToString("dd/MM/yyyy")} - Bây giờ là {DateTime.Now.ToString("hh:mm:ss tt")}";
        }


    }
}
