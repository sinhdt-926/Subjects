﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai04
{
    public partial class Form1 : Form
    {
        private string currentFilePath = string.Empty;
        private string currentExtension = string.Empty;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Tạo dữ liệu cho ComboBox Font
            foreach (FontFamily font in FontFamily.Families)
                tsCb_Font.Items.Add(font.Name);

            // Tạo dữ liệu cho ComboBox Size
            float[] sizes = { 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72 };
            foreach (float size in sizes)
                tsCb_Size.Items.Add(size.ToString());

            // Thiết lập mặc định: Font Tahoma - Size 14
            DefaultSettings();
        }

        // Thiết lập giá trị mặc định cho soạn thảo
        private void DefaultSettings()
        {
            Font defaultFont = new Font("Tahoma", 14, FontStyle.Regular);
            rtbText.Font = defaultFont;

            tsCb_Font.Text = "Tahoma";
            tsCb_Size.Text = "14";

            currentFilePath = string.Empty;
            currentExtension = string.Empty;
        }


        // Tạo văn bản mới - xóa nội dung & khởi tạo mặc định
        private void tsBtn_New_Click(object sender, EventArgs e)
        {
            rtbText.Clear();
            DefaultSettings();
        }

        private void tsTaoVanBan_Click(object sender, EventArgs e)
        {
            rtbText.Clear();
            DefaultSettings();
        }


        // Mở file TXT/RTF
        private void tsMoTapTin_Click(object sender, EventArgs e)
        {
            OpenFileDialog openDlg = new OpenFileDialog();
            openDlg.Filter = "Rich Text Files (*.rtf)|*.rtf|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";

            if (openDlg.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string extension = Path.GetExtension(openDlg.FileName).ToLower();
                    currentFilePath = openDlg.FileName;
                    currentExtension = extension;

                    if (extension == ".rtf")
                    {
                        rtbText.LoadFile(openDlg.FileName, RichTextBoxStreamType.RichText);
                    }
                    else if (extension == ".txt")
                    {
                        // Đọc TXT bằng UTF-8
                        string content = File.ReadAllText(openDlg.FileName, Encoding.UTF8);
                        rtbText.Text = content;
                    }
                    else
                    {
                        rtbText.LoadFile(openDlg.FileName, RichTextBoxStreamType.PlainText);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Không thể mở tập tin: " + ex.Message, "Lỗi Mở File",
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void tsBtn_Open_Click(object sender, EventArgs e)
        {
            tsMoTapTin_Click(sender, e);
        }


        // Lưu nội dung văn bản (theo loại file)
        private void tsLuu_Click(object sender, EventArgs e)
        {
            // Nếu là file mới → chọn nơi lưu
            if (string.IsNullOrEmpty(currentFilePath))
            {
                SaveFileDialog saveDlg = new SaveFileDialog();
                saveDlg.Filter = "Rich Text Files (*.rtf)|*.rtf|Text Files (*.txt)|*.txt";

                if (saveDlg.ShowDialog() == DialogResult.OK)
                {
                    currentFilePath = saveDlg.FileName;
                    currentExtension = Path.GetExtension(currentFilePath).ToLower();

                    SaveContent();
                    MessageBox.Show("Lưu văn bản mới thành công!", "Thông báo");
                }
                return;
            }

            // Nếu file đã mở trước đó → lưu đè
            SaveContent();
            MessageBox.Show("Lưu văn bản thành công!", "Thông báo");
        }

        private void tsBtn_Save_Click(object sender, EventArgs e)
        {
            tsLuu_Click(sender, e);
        }

        // Hàm lưu nội dung theo loại tập tin (RTF hoặc TXT)
        private void SaveContent()
        {
            if (currentExtension == ".rtf")
            {
                rtbText.SaveFile(currentFilePath, RichTextBoxStreamType.RichText);
            }
            else if (currentExtension == ".txt")
            {
                File.WriteAllText(currentFilePath, rtbText.Text, Encoding.UTF8);
            }
        }


        // Hộp thoại định dạng font + màu chữ
        private void msDinhDang_Click(object sender, EventArgs e)
        {
            FontDialog fontDlg = new FontDialog();
            fontDlg.Font = rtbText.SelectionFont;
            fontDlg.Color = rtbText.SelectionColor;
            fontDlg.ShowColor = true;

            if (fontDlg.ShowDialog() == DialogResult.OK)
            {
                rtbText.SelectionFont = fontDlg.Font;
                rtbText.SelectionColor = fontDlg.Color;
            }
        }


        // Đổi font chữ theo ComboBox
        private void tsCb_Font_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rtbText.SelectionFont == null) return;

            try
            {
                string newFontName = tsCb_Font.Text;
                float currentSize = rtbText.SelectionFont.Size;
                FontStyle currentStyle = rtbText.SelectionFont.Style;

                rtbText.SelectionFont = new Font(newFontName, currentSize, currentStyle);
            }
            catch { }
        }

        // Đổi cỡ chữ theo ComboBox
        private void tsCb_Size_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rtbText.SelectionFont == null) return;

            try
            {
                float newSize = float.Parse(tsCb_Size.Text);
                string currentFontName = rtbText.SelectionFont.Name;
                FontStyle currentStyle = rtbText.SelectionFont.Style;

                rtbText.SelectionFont = new Font(currentFontName, newSize, currentStyle);
            }
            catch { }
        }


        // Bật/Tắt Bold, Italic, Underline
        private void ToggleFontStyle(FontStyle style)
        {
            if (rtbText.SelectionFont == null) return;

            Font f = rtbText.SelectionFont;
            FontStyle newStyle = f.Style ^ style; // XOR để Toggle

            rtbText.SelectionFont = new Font(f.FontFamily, f.Size, newStyle);
        }

        private void tsBtn_Bold_Click(object sender, EventArgs e)
        {
            ToggleFontStyle(FontStyle.Bold);
        }

        private void tsBtn_Italic_Click(object sender, EventArgs e)
        {
            ToggleFontStyle(FontStyle.Italic);
        }

        private void tsBtn_Underline_Click(object sender, EventArgs e)
        {
            ToggleFontStyle(FontStyle.Underline);
        }


        // Cập nhật trạng thái B/I/U và Font/Size khi đổi Selection
        private void rtbText_SelectionChanged(object sender, EventArgs e)
        {
            if (rtbText.SelectionFont != null)
            {
                tsCb_Font.Text = rtbText.SelectionFont.Name;
                tsCb_Size.Text = rtbText.SelectionFont.Size.ToString();

                tsBtn_Bold.Checked = rtbText.SelectionFont.Bold;
                tsBtn_Italic.Checked = rtbText.SelectionFont.Italic;
                tsBtn_Underline.Checked = rtbText.SelectionFont.Underline;
            }
        }


        private void tsThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
