﻿namespace Bai04
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.msHeThong = new System.Windows.Forms.ToolStripMenuItem();
            this.tsTaoVanBan = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMoTapTin = new System.Windows.Forms.ToolStripMenuItem();
            this.tsLuu = new System.Windows.Forms.ToolStripMenuItem();
            this.tsThoat = new System.Windows.Forms.ToolStripMenuItem();
            this.msDinhDang = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsBtn_New = new System.Windows.Forms.ToolStripButton();
            this.tsBtn_Save = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsCb_Font = new System.Windows.Forms.ToolStripComboBox();
            this.tsCb_Size = new System.Windows.Forms.ToolStripComboBox();
            this.tsBtn_Bold = new System.Windows.Forms.ToolStripButton();
            this.tsBtn_Italic = new System.Windows.Forms.ToolStripButton();
            this.tsBtn_Underline = new System.Windows.Forms.ToolStripButton();
            this.rtbText = new System.Windows.Forms.RichTextBox();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.msHeThong,
            this.msDinhDang});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1201, 31);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // msHeThong
            // 
            this.msHeThong.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.msHeThong.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsTaoVanBan,
            this.tsMoTapTin,
            this.tsLuu,
            this.tsThoat});
            this.msHeThong.Name = "msHeThong";
            this.msHeThong.Size = new System.Drawing.Size(96, 27);
            this.msHeThong.Text = "Hệ thống";
            // 
            // tsTaoVanBan
            // 
            this.tsTaoVanBan.BackColor = System.Drawing.SystemColors.Menu;
            this.tsTaoVanBan.Image = ((System.Drawing.Image)(resources.GetObject("tsTaoVanBan.Image")));
            this.tsTaoVanBan.Name = "tsTaoVanBan";
            this.tsTaoVanBan.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.tsTaoVanBan.Size = new System.Drawing.Size(320, 28);
            this.tsTaoVanBan.Text = "Tạo văn bản mới";
            this.tsTaoVanBan.Click += new System.EventHandler(this.tsTaoVanBan_Click);
            // 
            // tsMoTapTin
            // 
            this.tsMoTapTin.BackColor = System.Drawing.SystemColors.Menu;
            this.tsMoTapTin.Image = ((System.Drawing.Image)(resources.GetObject("tsMoTapTin.Image")));
            this.tsMoTapTin.Name = "tsMoTapTin";
            this.tsMoTapTin.Size = new System.Drawing.Size(320, 28);
            this.tsMoTapTin.Text = "Mở tập tin";
            this.tsMoTapTin.Click += new System.EventHandler(this.tsMoTapTin_Click);
            // 
            // tsLuu
            // 
            this.tsLuu.BackColor = System.Drawing.SystemColors.Menu;
            this.tsLuu.Image = ((System.Drawing.Image)(resources.GetObject("tsLuu.Image")));
            this.tsLuu.Name = "tsLuu";
            this.tsLuu.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.tsLuu.Size = new System.Drawing.Size(320, 28);
            this.tsLuu.Text = "Lưu nội dung văn bản";
            this.tsLuu.Click += new System.EventHandler(this.tsLuu_Click);
            // 
            // tsThoat
            // 
            this.tsThoat.BackColor = System.Drawing.SystemColors.Menu;
            this.tsThoat.Image = global::Bai04.Properties.Resources.Logout;
            this.tsThoat.Name = "tsThoat";
            this.tsThoat.Size = new System.Drawing.Size(320, 28);
            this.tsThoat.Text = "Thoát";
            this.tsThoat.Click += new System.EventHandler(this.tsThoat_Click);
            // 
            // msDinhDang
            // 
            this.msDinhDang.Name = "msDinhDang";
            this.msDinhDang.Size = new System.Drawing.Size(104, 27);
            this.msDinhDang.Text = "Định dạng";
            this.msDinhDang.Click += new System.EventHandler(this.msDinhDang_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.Gainsboro;
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBtn_New,
            this.tsBtn_Save,
            this.toolStripSeparator1,
            this.tsCb_Font,
            this.tsCb_Size,
            this.tsBtn_Bold,
            this.tsBtn_Italic,
            this.tsBtn_Underline});
            this.toolStrip1.Location = new System.Drawing.Point(0, 31);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1201, 31);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsBtn_New
            // 
            this.tsBtn_New.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsBtn_New.Image = ((System.Drawing.Image)(resources.GetObject("tsBtn_New.Image")));
            this.tsBtn_New.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtn_New.Name = "tsBtn_New";
            this.tsBtn_New.Size = new System.Drawing.Size(29, 28);
            this.tsBtn_New.Text = "Add new file";
            this.tsBtn_New.Click += new System.EventHandler(this.tsBtn_New_Click);
            // 
            // tsBtn_Save
            // 
            this.tsBtn_Save.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsBtn_Save.Image = ((System.Drawing.Image)(resources.GetObject("tsBtn_Save.Image")));
            this.tsBtn_Save.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtn_Save.Name = "tsBtn_Save";
            this.tsBtn_Save.Size = new System.Drawing.Size(29, 28);
            this.tsBtn_Save.Text = "Save";
            this.tsBtn_Save.Click += new System.EventHandler(this.tsBtn_Save_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 31);
            // 
            // tsCb_Font
            // 
            this.tsCb_Font.Name = "tsCb_Font";
            this.tsCb_Font.Size = new System.Drawing.Size(190, 31);
            this.tsCb_Font.SelectedIndexChanged += new System.EventHandler(this.tsCb_Font_SelectedIndexChanged);
            // 
            // tsCb_Size
            // 
            this.tsCb_Size.Name = "tsCb_Size";
            this.tsCb_Size.Size = new System.Drawing.Size(80, 31);
            this.tsCb_Size.SelectedIndexChanged += new System.EventHandler(this.tsCb_Size_SelectedIndexChanged);
            // 
            // tsBtn_Bold
            // 
            this.tsBtn_Bold.BackColor = System.Drawing.Color.Gainsboro;
            this.tsBtn_Bold.CheckOnClick = true;
            this.tsBtn_Bold.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsBtn_Bold.Image = ((System.Drawing.Image)(resources.GetObject("tsBtn_Bold.Image")));
            this.tsBtn_Bold.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtn_Bold.Name = "tsBtn_Bold";
            this.tsBtn_Bold.Size = new System.Drawing.Size(29, 28);
            this.tsBtn_Bold.Text = "Bold";
            this.tsBtn_Bold.Click += new System.EventHandler(this.tsBtn_Bold_Click);
            // 
            // tsBtn_Italic
            // 
            this.tsBtn_Italic.BackColor = System.Drawing.Color.Gainsboro;
            this.tsBtn_Italic.CheckOnClick = true;
            this.tsBtn_Italic.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsBtn_Italic.Image = ((System.Drawing.Image)(resources.GetObject("tsBtn_Italic.Image")));
            this.tsBtn_Italic.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtn_Italic.Name = "tsBtn_Italic";
            this.tsBtn_Italic.Size = new System.Drawing.Size(29, 28);
            this.tsBtn_Italic.Text = "Italic";
            this.tsBtn_Italic.Click += new System.EventHandler(this.tsBtn_Italic_Click);
            // 
            // tsBtn_Underline
            // 
            this.tsBtn_Underline.CheckOnClick = true;
            this.tsBtn_Underline.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsBtn_Underline.Image = ((System.Drawing.Image)(resources.GetObject("tsBtn_Underline.Image")));
            this.tsBtn_Underline.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtn_Underline.Name = "tsBtn_Underline";
            this.tsBtn_Underline.Size = new System.Drawing.Size(29, 28);
            this.tsBtn_Underline.Text = "Underline";
            this.tsBtn_Underline.Click += new System.EventHandler(this.tsBtn_Underline_Click);
            // 
            // rtbText
            // 
            this.rtbText.BackColor = System.Drawing.Color.White;
            this.rtbText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtbText.Location = new System.Drawing.Point(0, 62);
            this.rtbText.Name = "rtbText";
            this.rtbText.Size = new System.Drawing.Size(1201, 572);
            this.rtbText.TabIndex = 2;
            this.rtbText.Text = "";
            this.rtbText.SelectionChanged += new System.EventHandler(this.rtbText_SelectionChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1201, 634);
            this.Controls.Add(this.rtbText);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem msHeThong;
        private System.Windows.Forms.ToolStripMenuItem tsTaoVanBan;
        private System.Windows.Forms.ToolStripMenuItem tsMoTapTin;
        private System.Windows.Forms.ToolStripMenuItem tsLuu;
        private System.Windows.Forms.ToolStripMenuItem tsThoat;
        private System.Windows.Forms.ToolStripMenuItem msDinhDang;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsBtn_New;
        private System.Windows.Forms.ToolStripButton tsBtn_Save;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripComboBox tsCb_Font;
        private System.Windows.Forms.ToolStripComboBox tsCb_Size;
        private System.Windows.Forms.ToolStripButton tsBtn_Bold;
        private System.Windows.Forms.ToolStripButton tsBtn_Italic;
        private System.Windows.Forms.ToolStripButton tsBtn_Underline;
        private System.Windows.Forms.RichTextBox rtbText;
    }
}

