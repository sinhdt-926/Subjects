﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai05
{
    public partial class FormQLSV : Form
    {
        public class SinhVien
        {
            public string MSSV { get; set; }
            public string TenSV { get; set; }
            public string Khoa { get; set; }
            public double DTB { get; set; }
        }

        private List<SinhVien> dsSV = new List<SinhVien>();

        public FormQLSV()
        {
            InitializeComponent();
        }

        private void tsBtn_ThemMoi_Click(object sender, EventArgs e)
        {
            Form_ThemSV frm = new Form_ThemSV();

            if (frm.ShowDialog() == DialogResult.OK)
            {
                dsSV.Add(frm.NewStudent);
                LoadData(dsSV);
            }
        }

        private void tsTxt_TimKiem_TextChanged(object sender, EventArgs e)
        {
            string txt = tsTxt_TimKiem.Text.Trim().ToLower();
            var filtered = dsSV.Where(s => s.TenSV.ToLower().Contains(txt)).ToList();
            LoadData(filtered);
        }
        private void LoadData(List<SinhVien> list)
        {
            dataGridView1.Rows.Clear();

            int stt = 1;
            foreach (var sv in list)
            {
                dataGridView1.Rows.Add(stt++, sv.MSSV, sv.TenSV, sv.Khoa, sv.DTB);
            }
        }

        private void tsMenuThemMoi_Click(object sender, EventArgs e)
        {
            tsBtn_ThemMoi_Click(sender, e);
        }

        private void tsMenuThoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}