﻿namespace Bai05
{
    partial class FormQLSV
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tsMenuChucNang = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMenuThemMoi = new System.Windows.Forms.ToolStripMenuItem();
            this.tsMenuThoat = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsBtn_ThemMoi = new System.Windows.Forms.ToolStripButton();
            this.tsLbl_TimKiem = new System.Windows.Forms.ToolStripLabel();
            this.tsTxt_TimKiem = new System.Windows.Forms.ToolStripTextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.SoTT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MSSV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenSV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Khoa = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DiemTB = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Gainsboro;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMenuChucNang});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(970, 31);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tsMenuChucNang
            // 
            this.tsMenuChucNang.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsMenuThemMoi,
            this.tsMenuThoat});
            this.tsMenuChucNang.Name = "tsMenuChucNang";
            this.tsMenuChucNang.Size = new System.Drawing.Size(107, 27);
            this.tsMenuChucNang.Text = "Chức năng";
            // 
            // tsMenuThemMoi
            // 
            this.tsMenuThemMoi.Image = global::Bai05.Properties.Resources.Add_User;
            this.tsMenuThemMoi.Name = "tsMenuThemMoi";
            this.tsMenuThemMoi.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.tsMenuThemMoi.Size = new System.Drawing.Size(233, 28);
            this.tsMenuThemMoi.Text = "Thêm mới";
            this.tsMenuThemMoi.Click += new System.EventHandler(this.tsMenuThemMoi_Click);
            // 
            // tsMenuThoat
            // 
            this.tsMenuThoat.Image = global::Bai05.Properties.Resources.Logout;
            this.tsMenuThoat.Name = "tsMenuThoat";
            this.tsMenuThoat.Size = new System.Drawing.Size(233, 28);
            this.tsMenuThoat.Text = "Thoát";
            this.tsMenuThoat.Click += new System.EventHandler(this.tsMenuThoat_Click);
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBtn_ThemMoi,
            this.tsLbl_TimKiem,
            this.tsTxt_TimKiem});
            this.toolStrip1.Location = new System.Drawing.Point(0, 31);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(970, 35);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsBtn_ThemMoi
            // 
            this.tsBtn_ThemMoi.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tsBtn_ThemMoi.Image = global::Bai05.Properties.Resources.Add_User;
            this.tsBtn_ThemMoi.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtn_ThemMoi.Margin = new System.Windows.Forms.Padding(0, 1, 20, 2);
            this.tsBtn_ThemMoi.Name = "tsBtn_ThemMoi";
            this.tsBtn_ThemMoi.Size = new System.Drawing.Size(123, 32);
            this.tsBtn_ThemMoi.Text = "Thêm mới";
            this.tsBtn_ThemMoi.Click += new System.EventHandler(this.tsBtn_ThemMoi_Click);
            // 
            // tsLbl_TimKiem
            // 
            this.tsLbl_TimKiem.Name = "tsLbl_TimKiem";
            this.tsLbl_TimKiem.Size = new System.Drawing.Size(149, 32);
            this.tsLbl_TimKiem.Text = "Tìm kiếm theo tên";
            // 
            // tsTxt_TimKiem
            // 
            this.tsTxt_TimKiem.Font = new System.Drawing.Font("Segoe UI", 10.2F);
            this.tsTxt_TimKiem.Name = "tsTxt_TimKiem";
            this.tsTxt_TimKiem.Size = new System.Drawing.Size(200, 35);
            this.tsTxt_TimKiem.TextChanged += new System.EventHandler(this.tsTxt_TimKiem_TextChanged);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SoTT,
            this.MSSV,
            this.TenSV,
            this.Khoa,
            this.DiemTB});
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 66);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(970, 387);
            this.dataGridView1.TabIndex = 2;
            // 
            // SoTT
            // 
            this.SoTT.HeaderText = "Số TT";
            this.SoTT.MinimumWidth = 6;
            this.SoTT.Name = "SoTT";
            this.SoTT.Width = 75;
            // 
            // MSSV
            // 
            this.MSSV.HeaderText = "Mã số SV";
            this.MSSV.MinimumWidth = 6;
            this.MSSV.Name = "MSSV";
            this.MSSV.Width = 125;
            // 
            // TenSV
            // 
            this.TenSV.HeaderText = "Tên Sinh viên";
            this.TenSV.MinimumWidth = 6;
            this.TenSV.Name = "TenSV";
            this.TenSV.Width = 200;
            // 
            // Khoa
            // 
            this.Khoa.HeaderText = "Khoa";
            this.Khoa.MinimumWidth = 6;
            this.Khoa.Name = "Khoa";
            this.Khoa.Width = 200;
            // 
            // DiemTB
            // 
            this.DiemTB.HeaderText = "Điểm TB";
            this.DiemTB.MinimumWidth = 6;
            this.DiemTB.Name = "DiemTB";
            this.DiemTB.Width = 75;
            // 
            // FormQLSV
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 453);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FormQLSV";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý sinh viên";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsMenuChucNang;
        private System.Windows.Forms.ToolStripMenuItem tsMenuThemMoi;
        private System.Windows.Forms.ToolStripMenuItem tsMenuThoat;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsBtn_ThemMoi;
        private System.Windows.Forms.ToolStripLabel tsLbl_TimKiem;
        private System.Windows.Forms.ToolStripTextBox tsTxt_TimKiem;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoTT;
        private System.Windows.Forms.DataGridViewTextBoxColumn MSSV;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenSV;
        private System.Windows.Forms.DataGridViewTextBoxColumn Khoa;
        private System.Windows.Forms.DataGridViewTextBoxColumn DiemTB;
    }
}