﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Bai05.FormQLSV;

namespace Bai05
{
    public partial class Form_ThemSV : Form
    {
        public SinhVien NewStudent { get; private set; }

        public Form_ThemSV()
        {
            InitializeComponent();
        }

        private void Form_ThemSV_Load(object sender, EventArgs e)
        {
            cbKhoa.Items.AddRange(new object[] {
                "Công nghệ thông tin", "Khoa học & KTTT", "Mạng máy tính & TTDL", "Hệ thống thông tin", "Kỹ thuật máy tính", "Khoa học máy tính", "Công nghệ phần mềm" });
        }

        private void btn_Thoat_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_ThemMoi_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtMSSV.Text) || string.IsNullOrEmpty(txtTenSV.Text) || string.IsNullOrEmpty(txtDTB.Text) || cbKhoa.SelectedIndex < 0)
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo");
                return;
            }

            double.TryParse(txtDTB.Text, out double dtb);

            if (dtb < 0 || dtb > 10)
            {
                MessageBox.Show("Điểm TB phải nằm trong khoảng 0–10!", "Lỗi");
                txtDTB.Focus();
                return;
            }

            NewStudent = new SinhVien
            {
                MSSV = txtMSSV.Text.Trim(),
                TenSV = txtTenSV.Text.Trim(),
                Khoa = cbKhoa.SelectedItem.ToString(),
                DTB = dtb
            };

            DialogResult = DialogResult.OK;
            Close();
        }

        private void txtDTB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsControl(e.KeyChar))
                return;

            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.')
            {
                e.Handled = true;
                return;
            }

            if (e.KeyChar == '.' && txtDTB.Text.Contains("."))
            {
                e.Handled = true;
            }
        }
    }
}